﻿namespace WarfareStrategy_v3
{
    partial class Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form));
            this.label1 = new System.Windows.Forms.Label();
            this.Menu1 = new System.Windows.Forms.Panel();
            this.Setting_Button = new System.Windows.Forms.Button();
            this.Exit_Button = new System.Windows.Forms.Button();
            this.Addon_Button = new System.Windows.Forms.Button();
            this.Play_Button = new System.Windows.Forms.Button();
            this.Menu2 = new System.Windows.Forms.Panel();
            this.add_Back_Button = new System.Windows.Forms.Button();
            this.add_Random_Button = new System.Windows.Forms.Button();
            this.add_Master_Button = new System.Windows.Forms.Button();
            this.add_Timer_Button = new System.Windows.Forms.Button();
            this.PlayerDeck_PictureBox = new System.Windows.Forms.PictureBox();
            this.OpponentDeck_PictureBox = new System.Windows.Forms.PictureBox();
            this.PlayerHand_Panel = new System.Windows.Forms.Panel();
            this.PlayerHand5_PictureBox = new System.Windows.Forms.PictureBox();
            this.PlayerHand4_PictureBox = new System.Windows.Forms.PictureBox();
            this.PlayerHand2_PictureBox = new System.Windows.Forms.PictureBox();
            this.PlayerHand3_PictureBox = new System.Windows.Forms.PictureBox();
            this.PlayerHand1_PictureBox = new System.Windows.Forms.PictureBox();
            this.InitialSetup_Timer = new System.Windows.Forms.Timer(this.components);
            this.OpponentHand_Panel = new System.Windows.Forms.Panel();
            this.OpponentHand5_PictureBox = new System.Windows.Forms.PictureBox();
            this.OpponentHand4_PictureBox = new System.Windows.Forms.PictureBox();
            this.OpponentHand2_PictureBox = new System.Windows.Forms.PictureBox();
            this.OpponentHand3_PictureBox = new System.Windows.Forms.PictureBox();
            this.OpponentHand1_PictureBox = new System.Windows.Forms.PictureBox();
            this.Menu3 = new System.Windows.Forms.Panel();
            this.sett_Back_Button = new System.Windows.Forms.Button();
            this.sett_GameSpeed_Button = new System.Windows.Forms.Button();
            this.sett_Console_Button = new System.Windows.Forms.Button();
            this.sett_Sound_Button = new System.Windows.Forms.Button();
            this.sett_Popup_Label = new System.Windows.Forms.Label();
            this.sett_Popup_Timer = new System.Windows.Forms.Timer(this.components);
            this.Menu1.SuspendLayout();
            this.Menu2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerDeck_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentDeck_PictureBox)).BeginInit();
            this.PlayerHand_Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHand5_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHand4_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHand2_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHand3_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHand1_PictureBox)).BeginInit();
            this.OpponentHand_Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentHand5_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentHand4_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentHand2_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentHand3_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentHand1_PictureBox)).BeginInit();
            this.Menu3.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(1238, 808);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(20, 15);
            this.label1.TabIndex = 4;
            this.label1.Text = "v3";
            // 
            // Menu1
            // 
            this.Menu1.BackColor = System.Drawing.Color.Transparent;
            this.Menu1.Controls.Add(this.Setting_Button);
            this.Menu1.Controls.Add(this.Exit_Button);
            this.Menu1.Controls.Add(this.Addon_Button);
            this.Menu1.Controls.Add(this.Play_Button);
            this.Menu1.Location = new System.Drawing.Point(590, 451);
            this.Menu1.Name = "Menu1";
            this.Menu1.Size = new System.Drawing.Size(90, 133);
            this.Menu1.TabIndex = 9;
            // 
            // Setting_Button
            // 
            this.Setting_Button.BackColor = System.Drawing.Color.DarkGray;
            this.Setting_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Setting_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.Setting_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Setting_Button.Location = new System.Drawing.Point(0, 71);
            this.Setting_Button.Name = "Setting_Button";
            this.Setting_Button.Size = new System.Drawing.Size(90, 28);
            this.Setting_Button.TabIndex = 7;
            this.Setting_Button.TabStop = false;
            this.Setting_Button.Text = "Settings";
            this.Setting_Button.UseVisualStyleBackColor = false;
            this.Setting_Button.Click += new System.EventHandler(this.Setting_Button_Click);
            // 
            // Exit_Button
            // 
            this.Exit_Button.BackColor = System.Drawing.Color.DarkGray;
            this.Exit_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Exit_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.Exit_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Exit_Button.Location = new System.Drawing.Point(0, 105);
            this.Exit_Button.Name = "Exit_Button";
            this.Exit_Button.Size = new System.Drawing.Size(90, 28);
            this.Exit_Button.TabIndex = 6;
            this.Exit_Button.TabStop = false;
            this.Exit_Button.Text = "Exit";
            this.Exit_Button.UseVisualStyleBackColor = false;
            this.Exit_Button.Click += new System.EventHandler(this.Exit_Button_Click);
            // 
            // Addon_Button
            // 
            this.Addon_Button.BackColor = System.Drawing.Color.DarkGray;
            this.Addon_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Addon_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.Addon_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Addon_Button.Location = new System.Drawing.Point(0, 35);
            this.Addon_Button.Name = "Addon_Button";
            this.Addon_Button.Size = new System.Drawing.Size(90, 28);
            this.Addon_Button.TabIndex = 5;
            this.Addon_Button.TabStop = false;
            this.Addon_Button.Text = "Addons";
            this.Addon_Button.UseVisualStyleBackColor = false;
            this.Addon_Button.Click += new System.EventHandler(this.Addon_Button_Click);
            // 
            // Play_Button
            // 
            this.Play_Button.BackColor = System.Drawing.Color.DarkGray;
            this.Play_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Play_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.Play_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Play_Button.Location = new System.Drawing.Point(0, 0);
            this.Play_Button.Name = "Play_Button";
            this.Play_Button.Size = new System.Drawing.Size(90, 28);
            this.Play_Button.TabIndex = 4;
            this.Play_Button.TabStop = false;
            this.Play_Button.Text = "Play Game";
            this.Play_Button.UseVisualStyleBackColor = false;
            this.Play_Button.Click += new System.EventHandler(this.Play_Button_Click);
            // 
            // Menu2
            // 
            this.Menu2.BackColor = System.Drawing.Color.Transparent;
            this.Menu2.Controls.Add(this.add_Back_Button);
            this.Menu2.Controls.Add(this.add_Random_Button);
            this.Menu2.Controls.Add(this.add_Master_Button);
            this.Menu2.Controls.Add(this.add_Timer_Button);
            this.Menu2.Cursor = System.Windows.Forms.Cursors.Default;
            this.Menu2.Location = new System.Drawing.Point(590, 451);
            this.Menu2.Name = "Menu2";
            this.Menu2.Size = new System.Drawing.Size(90, 133);
            this.Menu2.TabIndex = 10;
            this.Menu2.Visible = false;
            // 
            // add_Back_Button
            // 
            this.add_Back_Button.BackColor = System.Drawing.Color.DarkGray;
            this.add_Back_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.add_Back_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.add_Back_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.add_Back_Button.Location = new System.Drawing.Point(5, 105);
            this.add_Back_Button.Name = "add_Back_Button";
            this.add_Back_Button.Size = new System.Drawing.Size(80, 28);
            this.add_Back_Button.TabIndex = 12;
            this.add_Back_Button.TabStop = false;
            this.add_Back_Button.Text = "Back";
            this.add_Back_Button.UseVisualStyleBackColor = false;
            this.add_Back_Button.Click += new System.EventHandler(this.add_Back_Button_Click);
            // 
            // add_Random_Button
            // 
            this.add_Random_Button.BackColor = System.Drawing.Color.DarkGray;
            this.add_Random_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.add_Random_Button.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.add_Random_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.add_Random_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.add_Random_Button.Location = new System.Drawing.Point(-2, 71);
            this.add_Random_Button.Name = "add_Random_Button";
            this.add_Random_Button.Size = new System.Drawing.Size(94, 28);
            this.add_Random_Button.TabIndex = 11;
            this.add_Random_Button.TabStop = false;
            this.add_Random_Button.Text = "Random Deck";
            this.add_Random_Button.UseVisualStyleBackColor = false;
            this.add_Random_Button.Click += new System.EventHandler(this.add_Random_Button_Click);
            // 
            // add_Master_Button
            // 
            this.add_Master_Button.BackColor = System.Drawing.Color.DarkGray;
            this.add_Master_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.add_Master_Button.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.add_Master_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.add_Master_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.add_Master_Button.Location = new System.Drawing.Point(-2, 35);
            this.add_Master_Button.Name = "add_Master_Button";
            this.add_Master_Button.Size = new System.Drawing.Size(94, 28);
            this.add_Master_Button.TabIndex = 10;
            this.add_Master_Button.TabStop = false;
            this.add_Master_Button.Text = "Master Mode";
            this.add_Master_Button.UseVisualStyleBackColor = false;
            this.add_Master_Button.Click += new System.EventHandler(this.add_Master_Button_Click);
            // 
            // add_Timer_Button
            // 
            this.add_Timer_Button.BackColor = System.Drawing.Color.DarkGray;
            this.add_Timer_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.add_Timer_Button.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.add_Timer_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.add_Timer_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.add_Timer_Button.Location = new System.Drawing.Point(-2, 0);
            this.add_Timer_Button.Name = "add_Timer_Button";
            this.add_Timer_Button.Size = new System.Drawing.Size(94, 28);
            this.add_Timer_Button.TabIndex = 9;
            this.add_Timer_Button.TabStop = false;
            this.add_Timer_Button.Text = "In-Game Timer";
            this.add_Timer_Button.UseVisualStyleBackColor = false;
            this.add_Timer_Button.Click += new System.EventHandler(this.add_Timer_Button_Click);
            // 
            // PlayerDeck_PictureBox
            // 
            this.PlayerDeck_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.PlayerDeck_PictureBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PlayerDeck_PictureBox.Enabled = false;
            this.PlayerDeck_PictureBox.Location = new System.Drawing.Point(244, 676);
            this.PlayerDeck_PictureBox.Name = "PlayerDeck_PictureBox";
            this.PlayerDeck_PictureBox.Size = new System.Drawing.Size(86, 148);
            this.PlayerDeck_PictureBox.TabIndex = 11;
            this.PlayerDeck_PictureBox.TabStop = false;
            this.PlayerDeck_PictureBox.Click += new System.EventHandler(this.PlayerDeck_PictureBox_Click);
            // 
            // OpponentDeck_PictureBox
            // 
            this.OpponentDeck_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.OpponentDeck_PictureBox.Location = new System.Drawing.Point(244, 2);
            this.OpponentDeck_PictureBox.Name = "OpponentDeck_PictureBox";
            this.OpponentDeck_PictureBox.Size = new System.Drawing.Size(86, 148);
            this.OpponentDeck_PictureBox.TabIndex = 12;
            this.OpponentDeck_PictureBox.TabStop = false;
            // 
            // PlayerHand_Panel
            // 
            this.PlayerHand_Panel.BackColor = System.Drawing.Color.Transparent;
            this.PlayerHand_Panel.Controls.Add(this.PlayerHand5_PictureBox);
            this.PlayerHand_Panel.Controls.Add(this.PlayerHand4_PictureBox);
            this.PlayerHand_Panel.Controls.Add(this.PlayerHand2_PictureBox);
            this.PlayerHand_Panel.Controls.Add(this.PlayerHand3_PictureBox);
            this.PlayerHand_Panel.Controls.Add(this.PlayerHand1_PictureBox);
            this.PlayerHand_Panel.Cursor = System.Windows.Forms.Cursors.Default;
            this.PlayerHand_Panel.Location = new System.Drawing.Point(450, 677);
            this.PlayerHand_Panel.Name = "PlayerHand_Panel";
            this.PlayerHand_Panel.Size = new System.Drawing.Size(472, 152);
            this.PlayerHand_Panel.TabIndex = 13;
            this.PlayerHand_Panel.Visible = false;
            // 
            // PlayerHand5_PictureBox
            // 
            this.PlayerHand5_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.PlayerHand5_PictureBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PlayerHand5_PictureBox.Enabled = false;
            this.PlayerHand5_PictureBox.Location = new System.Drawing.Point(385, 5);
            this.PlayerHand5_PictureBox.Name = "PlayerHand5_PictureBox";
            this.PlayerHand5_PictureBox.Size = new System.Drawing.Size(82, 142);
            this.PlayerHand5_PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PlayerHand5_PictureBox.TabIndex = 4;
            this.PlayerHand5_PictureBox.TabStop = false;
            this.PlayerHand5_PictureBox.Click += new System.EventHandler(this.PlayerHand5_PictureBox_Click);
            this.PlayerHand5_PictureBox.DoubleClick += new System.EventHandler(this.PlayerHand5_PictureBox_DoubleClick);
            // 
            // PlayerHand4_PictureBox
            // 
            this.PlayerHand4_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.PlayerHand4_PictureBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PlayerHand4_PictureBox.Enabled = false;
            this.PlayerHand4_PictureBox.Location = new System.Drawing.Point(290, 5);
            this.PlayerHand4_PictureBox.Name = "PlayerHand4_PictureBox";
            this.PlayerHand4_PictureBox.Size = new System.Drawing.Size(82, 142);
            this.PlayerHand4_PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PlayerHand4_PictureBox.TabIndex = 3;
            this.PlayerHand4_PictureBox.TabStop = false;
            this.PlayerHand4_PictureBox.Click += new System.EventHandler(this.PlayerHand4_PictureBox_Click);
            this.PlayerHand4_PictureBox.DoubleClick += new System.EventHandler(this.PlayerHand4_PictureBox_DoubleClick);
            // 
            // PlayerHand2_PictureBox
            // 
            this.PlayerHand2_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.PlayerHand2_PictureBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PlayerHand2_PictureBox.Enabled = false;
            this.PlayerHand2_PictureBox.Location = new System.Drawing.Point(100, 5);
            this.PlayerHand2_PictureBox.Name = "PlayerHand2_PictureBox";
            this.PlayerHand2_PictureBox.Size = new System.Drawing.Size(82, 142);
            this.PlayerHand2_PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PlayerHand2_PictureBox.TabIndex = 2;
            this.PlayerHand2_PictureBox.TabStop = false;
            this.PlayerHand2_PictureBox.Click += new System.EventHandler(this.PlayerHand2_PictureBox_Click);
            this.PlayerHand2_PictureBox.DoubleClick += new System.EventHandler(this.PlayerHand2_PictureBox_DoubleClick);
            // 
            // PlayerHand3_PictureBox
            // 
            this.PlayerHand3_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.PlayerHand3_PictureBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PlayerHand3_PictureBox.Enabled = false;
            this.PlayerHand3_PictureBox.Location = new System.Drawing.Point(195, 5);
            this.PlayerHand3_PictureBox.Name = "PlayerHand3_PictureBox";
            this.PlayerHand3_PictureBox.Size = new System.Drawing.Size(82, 142);
            this.PlayerHand3_PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PlayerHand3_PictureBox.TabIndex = 1;
            this.PlayerHand3_PictureBox.TabStop = false;
            this.PlayerHand3_PictureBox.Click += new System.EventHandler(this.PlayerHand3_PictureBox_Click);
            this.PlayerHand3_PictureBox.DoubleClick += new System.EventHandler(this.PlayerHand3_PictureBox_DoubleClick);
            // 
            // PlayerHand1_PictureBox
            // 
            this.PlayerHand1_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.PlayerHand1_PictureBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PlayerHand1_PictureBox.Enabled = false;
            this.PlayerHand1_PictureBox.Location = new System.Drawing.Point(5, 5);
            this.PlayerHand1_PictureBox.Name = "PlayerHand1_PictureBox";
            this.PlayerHand1_PictureBox.Size = new System.Drawing.Size(82, 142);
            this.PlayerHand1_PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PlayerHand1_PictureBox.TabIndex = 0;
            this.PlayerHand1_PictureBox.TabStop = false;
            this.PlayerHand1_PictureBox.Click += new System.EventHandler(this.PlayerHand1_PictureBox_Click);
            this.PlayerHand1_PictureBox.DoubleClick += new System.EventHandler(this.PlayerHand1_PictureBox_DoubleClick);
            // 
            // InitialSetup_Timer
            // 
            this.InitialSetup_Timer.Interval = 270;
            this.InitialSetup_Timer.Tick += new System.EventHandler(this.InitialSetup_Timer_Tick);
            // 
            // OpponentHand_Panel
            // 
            this.OpponentHand_Panel.BackColor = System.Drawing.Color.Transparent;
            this.OpponentHand_Panel.Controls.Add(this.OpponentHand5_PictureBox);
            this.OpponentHand_Panel.Controls.Add(this.OpponentHand4_PictureBox);
            this.OpponentHand_Panel.Controls.Add(this.OpponentHand2_PictureBox);
            this.OpponentHand_Panel.Controls.Add(this.OpponentHand3_PictureBox);
            this.OpponentHand_Panel.Controls.Add(this.OpponentHand1_PictureBox);
            this.OpponentHand_Panel.Location = new System.Drawing.Point(455, 8);
            this.OpponentHand_Panel.Name = "OpponentHand_Panel";
            this.OpponentHand_Panel.Size = new System.Drawing.Size(462, 142);
            this.OpponentHand_Panel.TabIndex = 14;
            // 
            // OpponentHand5_PictureBox
            // 
            this.OpponentHand5_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.OpponentHand5_PictureBox.Location = new System.Drawing.Point(380, 0);
            this.OpponentHand5_PictureBox.Name = "OpponentHand5_PictureBox";
            this.OpponentHand5_PictureBox.Size = new System.Drawing.Size(82, 142);
            this.OpponentHand5_PictureBox.TabIndex = 4;
            this.OpponentHand5_PictureBox.TabStop = false;
            // 
            // OpponentHand4_PictureBox
            // 
            this.OpponentHand4_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.OpponentHand4_PictureBox.Location = new System.Drawing.Point(285, 0);
            this.OpponentHand4_PictureBox.Name = "OpponentHand4_PictureBox";
            this.OpponentHand4_PictureBox.Size = new System.Drawing.Size(82, 142);
            this.OpponentHand4_PictureBox.TabIndex = 3;
            this.OpponentHand4_PictureBox.TabStop = false;
            // 
            // OpponentHand2_PictureBox
            // 
            this.OpponentHand2_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.OpponentHand2_PictureBox.Location = new System.Drawing.Point(95, 0);
            this.OpponentHand2_PictureBox.Name = "OpponentHand2_PictureBox";
            this.OpponentHand2_PictureBox.Size = new System.Drawing.Size(82, 142);
            this.OpponentHand2_PictureBox.TabIndex = 2;
            this.OpponentHand2_PictureBox.TabStop = false;
            // 
            // OpponentHand3_PictureBox
            // 
            this.OpponentHand3_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.OpponentHand3_PictureBox.Location = new System.Drawing.Point(190, 0);
            this.OpponentHand3_PictureBox.Name = "OpponentHand3_PictureBox";
            this.OpponentHand3_PictureBox.Size = new System.Drawing.Size(82, 142);
            this.OpponentHand3_PictureBox.TabIndex = 1;
            this.OpponentHand3_PictureBox.TabStop = false;
            // 
            // OpponentHand1_PictureBox
            // 
            this.OpponentHand1_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.OpponentHand1_PictureBox.Location = new System.Drawing.Point(0, 0);
            this.OpponentHand1_PictureBox.Name = "OpponentHand1_PictureBox";
            this.OpponentHand1_PictureBox.Size = new System.Drawing.Size(82, 142);
            this.OpponentHand1_PictureBox.TabIndex = 0;
            this.OpponentHand1_PictureBox.TabStop = false;
            // 
            // Menu3
            // 
            this.Menu3.BackColor = System.Drawing.Color.Transparent;
            this.Menu3.Controls.Add(this.sett_Back_Button);
            this.Menu3.Controls.Add(this.sett_GameSpeed_Button);
            this.Menu3.Controls.Add(this.sett_Console_Button);
            this.Menu3.Controls.Add(this.sett_Sound_Button);
            this.Menu3.Location = new System.Drawing.Point(590, 451);
            this.Menu3.Name = "Menu3";
            this.Menu3.Size = new System.Drawing.Size(90, 133);
            this.Menu3.TabIndex = 15;
            this.Menu3.Visible = false;
            this.Menu3.MouseHover += new System.EventHandler(this.Menu3_MouseHover);
            // 
            // sett_Back_Button
            // 
            this.sett_Back_Button.BackColor = System.Drawing.Color.DarkGray;
            this.sett_Back_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sett_Back_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.sett_Back_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sett_Back_Button.Location = new System.Drawing.Point(5, 105);
            this.sett_Back_Button.Name = "sett_Back_Button";
            this.sett_Back_Button.Size = new System.Drawing.Size(80, 28);
            this.sett_Back_Button.TabIndex = 13;
            this.sett_Back_Button.TabStop = false;
            this.sett_Back_Button.Text = "Back";
            this.sett_Back_Button.UseVisualStyleBackColor = false;
            this.sett_Back_Button.Click += new System.EventHandler(this.sett_Back_Button_Click);
            // 
            // sett_GameSpeed_Button
            // 
            this.sett_GameSpeed_Button.BackColor = System.Drawing.Color.DarkGray;
            this.sett_GameSpeed_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sett_GameSpeed_Button.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.sett_GameSpeed_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.sett_GameSpeed_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sett_GameSpeed_Button.Font = new System.Drawing.Font("Times New Roman", 8.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sett_GameSpeed_Button.Location = new System.Drawing.Point(-2, 71);
            this.sett_GameSpeed_Button.Name = "sett_GameSpeed_Button";
            this.sett_GameSpeed_Button.Size = new System.Drawing.Size(94, 28);
            this.sett_GameSpeed_Button.TabIndex = 12;
            this.sett_GameSpeed_Button.TabStop = false;
            this.sett_GameSpeed_Button.Text = "Game-Speed - 2";
            this.sett_GameSpeed_Button.UseVisualStyleBackColor = false;
            this.sett_GameSpeed_Button.Click += new System.EventHandler(this.sett_GameSpeed_Button_Click);
            this.sett_GameSpeed_Button.MouseHover += new System.EventHandler(this.sett_GameSpeed_Button_MouseHover);
            // 
            // sett_Console_Button
            // 
            this.sett_Console_Button.BackColor = System.Drawing.Color.DarkGray;
            this.sett_Console_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sett_Console_Button.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.sett_Console_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.sett_Console_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sett_Console_Button.Location = new System.Drawing.Point(-2, 35);
            this.sett_Console_Button.Name = "sett_Console_Button";
            this.sett_Console_Button.Size = new System.Drawing.Size(94, 28);
            this.sett_Console_Button.TabIndex = 11;
            this.sett_Console_Button.TabStop = false;
            this.sett_Console_Button.Text = "Console - off";
            this.sett_Console_Button.UseVisualStyleBackColor = false;
            this.sett_Console_Button.Click += new System.EventHandler(this.sett_Console_Button_Click);
            // 
            // sett_Sound_Button
            // 
            this.sett_Sound_Button.BackColor = System.Drawing.Color.DarkGray;
            this.sett_Sound_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sett_Sound_Button.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.sett_Sound_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.sett_Sound_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sett_Sound_Button.Location = new System.Drawing.Point(-2, 0);
            this.sett_Sound_Button.Name = "sett_Sound_Button";
            this.sett_Sound_Button.Size = new System.Drawing.Size(94, 28);
            this.sett_Sound_Button.TabIndex = 10;
            this.sett_Sound_Button.TabStop = false;
            this.sett_Sound_Button.Text = "Sound - on";
            this.sett_Sound_Button.UseVisualStyleBackColor = false;
            this.sett_Sound_Button.Click += new System.EventHandler(this.sett_Sound_Button_Click);
            // 
            // sett_Popup_Label
            // 
            this.sett_Popup_Label.BackColor = System.Drawing.Color.Transparent;
            this.sett_Popup_Label.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.sett_Popup_Label.Location = new System.Drawing.Point(688, 529);
            this.sett_Popup_Label.Name = "sett_Popup_Label";
            this.sett_Popup_Label.Size = new System.Drawing.Size(153, 102);
            this.sett_Popup_Label.TabIndex = 17;
            this.sett_Popup_Label.Text = "1 - slow,  2 - normal,  3 - fast";
            this.sett_Popup_Label.Visible = false;
            // 
            // sett_Popup_Timer
            // 
            this.sett_Popup_Timer.Interval = 1000;
            this.sett_Popup_Timer.Tick += new System.EventHandler(this.sett_Popup_Timer_Tick);
            // 
            // Form
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1270, 832);
            this.Controls.Add(this.sett_Popup_Label);
            this.Controls.Add(this.Menu3);
            this.Controls.Add(this.OpponentHand_Panel);
            this.Controls.Add(this.PlayerHand_Panel);
            this.Controls.Add(this.OpponentDeck_PictureBox);
            this.Controls.Add(this.PlayerDeck_PictureBox);
            this.Controls.Add(this.Menu2);
            this.Controls.Add(this.Menu1);
            this.Controls.Add(this.label1);
            this.Cursor = System.Windows.Forms.Cursors.Default;
            this.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "v3";
            this.MouseHover += new System.EventHandler(this.Form_MouseHover);
            this.Menu1.ResumeLayout(false);
            this.Menu2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PlayerDeck_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentDeck_PictureBox)).EndInit();
            this.PlayerHand_Panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHand5_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHand4_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHand2_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHand3_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHand1_PictureBox)).EndInit();
            this.OpponentHand_Panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.OpponentHand5_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentHand4_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentHand2_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentHand3_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentHand1_PictureBox)).EndInit();
            this.Menu3.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel Menu1;
        private System.Windows.Forms.Button Setting_Button;
        private System.Windows.Forms.Button Exit_Button;
        private System.Windows.Forms.Button Addon_Button;
        private System.Windows.Forms.Button Play_Button;
        private System.Windows.Forms.Panel Menu2;
        private System.Windows.Forms.Button add_Back_Button;
        private System.Windows.Forms.Button add_Random_Button;
        private System.Windows.Forms.Button add_Master_Button;
        private System.Windows.Forms.Button add_Timer_Button;
        private System.Windows.Forms.PictureBox PlayerDeck_PictureBox;
        private System.Windows.Forms.PictureBox OpponentDeck_PictureBox;
        private System.Windows.Forms.Panel PlayerHand_Panel;
        private System.Windows.Forms.PictureBox PlayerHand5_PictureBox;
        private System.Windows.Forms.PictureBox PlayerHand4_PictureBox;
        private System.Windows.Forms.PictureBox PlayerHand2_PictureBox;
        private System.Windows.Forms.PictureBox PlayerHand3_PictureBox;
        private System.Windows.Forms.PictureBox PlayerHand1_PictureBox;
        private System.Windows.Forms.Timer InitialSetup_Timer;
        private System.Windows.Forms.Panel OpponentHand_Panel;
        private System.Windows.Forms.PictureBox OpponentHand5_PictureBox;
        private System.Windows.Forms.PictureBox OpponentHand4_PictureBox;
        private System.Windows.Forms.PictureBox OpponentHand2_PictureBox;
        private System.Windows.Forms.PictureBox OpponentHand3_PictureBox;
        private System.Windows.Forms.PictureBox OpponentHand1_PictureBox;
        private System.Windows.Forms.Panel Menu3;
        private System.Windows.Forms.Button sett_Back_Button;
        private System.Windows.Forms.Button sett_GameSpeed_Button;
        private System.Windows.Forms.Button sett_Console_Button;
        private System.Windows.Forms.Button sett_Sound_Button;
        private System.Windows.Forms.Label sett_Popup_Label;
        private System.Windows.Forms.Timer sett_Popup_Timer;
    }
}

