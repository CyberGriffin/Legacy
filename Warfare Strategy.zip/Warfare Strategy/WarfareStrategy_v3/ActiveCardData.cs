﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WarfareStrategy_v3
{
    class ActiveCardData
    {
        public void DiscardPile_Data()
        {

        }

        public static int[] player_SlotActive = { 0, 0, 0 };
        public static int[] opponent_SlotActive = { 0, 0, 0 };

        
        public void CardSlot_Data()
        {
            //1


            //2


            //3


        }

        public static int[] max_SpecialSlotCapacity = { 1, 1 };
        public static bool player_SpecialSlotCapacityReached = false;
        public static bool opponent_SpecialSlotCapacityReached = false;
        public void CardSpecial_Data()
        {

        }
    }
}
