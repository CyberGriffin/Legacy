﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;

namespace WarfareStrategy_v3
{
    public partial class Form : System.Windows.Forms.Form
    {
        class Variable
        {
            #region <-----PlayerVariables----->
            public static int player_deckCount;
            public static int player_deckStage = 3;
            public static int player_team = 1;
            public static List<string> player_cards = new List<string>();

            public static bool[] player_handFlipped = { false, false, false, false, false };
            public static bool[] player_handFocused = { false, false, false, false, false };
            public static bool player_handCardSelected = false;

            public static object CurrentCardSelected = new object();
            #endregion

            #region <-----OpponentVariables----->
            public static int opponent_deckCount;
            public static int opponent_deckStage = 3;
            public static int opponent_team = 0;
            public static List<string> opponent_cards = new List<string>();
            #endregion

            #region <-----GameVariables----->
            public static int max_deckCount = 25;
            public static string[] team_list = { "RedTeam", "BlueTeam", "GrayTeam", "PurpleTeam" };
            public static string[] all_cardTypes = { "r0", "r1", "r2", "r3", "r4", "r5", "r6", "r7", "r8", "r9", "r10", "r11", "r12", "r13", "r14", "r15", "r16", "r17",
                                                     "b0", "b1", "b2", "b3", "b4", "b5", "b6", "b7", "b8", "b9", "b10", "b11", "b12", "b13", "b14", "b15", "b16", "b17",
                                                     "g0", "g1", "g2", "g3", "g4", "g5", "g6", "g7", "g8", "g9", "g10", "g11", "g12", "g13", "g14", "g15", "g16", "g17",
                                                     "p0", "p1", "p2", "p3", "p4", "p5", "p6", "p7", "p8", "p9", "p10", "p11", "p12", "p13", "p14", "p15", "p16", "p17" }; //0-17(redteam), 18-35(blueteam), 36-53(grayteam), 54-71(purpleteam) #EXAMPLE#
            public static int deck_timerCounter = 1;
            public static bool InitialSetup_Required = true;
            #endregion

            #region <-----Addon&SettingVariables----->
            //Addon
            public static bool addon_Timer_Active = false;
            public static bool addon_Master_Active = false;
            public static bool addon_Random_Active = false;

            //Setting
            public static bool sett_Sound_Active = true;
            public static bool sett_Console_Active = false;
            public static int sett_GameSpeed_Value = 2; // 3 = fast, 2 = normal, 1 = slow
            #endregion
        }


        #region <-----DeckManagement----->

        public void Player_GenerateDeck()
        {
            PlayerDeck_PictureBox.Enabled = true;
            Variable.player_deckCount = Variable.max_deckCount;
            PlayerDeck_PictureBox.Size = new Size(86, 148);
            PlayerDeck_PictureBox.Location = new Point(244, 676);
            PlayerDeck_PictureBox.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy_v3\GameObjects\PlayingCards\" + Variable.team_list[Variable.player_team] + @"\Deck_" + Variable.player_deckStage + ".png");

            if(Variable.addon_Random_Active == true)
            {
                Random rnd = new Random(Guid.NewGuid().GetHashCode());
                for (int i = 0; i != Variable.max_deckCount; i++)
                {                    
                    Variable.player_cards.Add(Variable.all_cardTypes[rnd.Next(1, Variable.all_cardTypes.Length)]);
                }
            } //For the random addon
            else
            {
                Random rnd = new Random(Guid.NewGuid().GetHashCode());
                if (Variable.player_team == 0)
                {
                    for(int i = 0; i <= Variable.max_deckCount; i++)
                    {
                        Variable.player_cards.Add(Variable.all_cardTypes[rnd.Next(1, 18)]);
                    }
                }
                else if(Variable.player_team == 1)
                {
                    for (int i = 0; i <= Variable.max_deckCount; i++)
                    {
                        Variable.player_cards.Add(Variable.all_cardTypes[rnd.Next(19, 36)]);
                    }
                }
                else if (Variable.player_team == 2)
                {
                    for (int i = 0; i <= Variable.max_deckCount; i++)
                    {
                        Variable.player_cards.Add(Variable.all_cardTypes[rnd.Next(37, 54)]);
                    }
                }
                else
                {
                    for (int i = 0; i <= Variable.max_deckCount; i++)
                    {
                        Variable.player_cards.Add(Variable.all_cardTypes[rnd.Next(55, 72)]);
                    }
                }
            }

            foreach (var o in Variable.player_cards)
            {
                Console.WriteLine("Player : " + o.ToString());
            } //Debugging
        }
        public void Opponent_GenerateDeck()
        {
            Variable.opponent_deckCount = Variable.max_deckCount;
            OpponentDeck_PictureBox.Size = new Size(86, 148);
            OpponentDeck_PictureBox.Location = new Point(244, 2);
            OpponentDeck_PictureBox.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy_v3\GameObjects\PlayingCards\" + Variable.team_list[Variable.opponent_team] + @"\Deck_" + Variable.opponent_deckStage + ".png");
           
            if(Variable.addon_Random_Active == true)
            {
                Random rnd = new Random(Guid.NewGuid().GetHashCode());
                for (int i = 0; i != Variable.max_deckCount; i++)
                {
                    Variable.opponent_cards.Add(Variable.all_cardTypes[rnd.Next(1, Variable.all_cardTypes.Length)]);
                }
            } //For the random addon 
            else
            {
                Random rnd = new Random(Guid.NewGuid().GetHashCode());
                if (Variable.opponent_team == 0)
                {
                    for (int i = 0; i <= Variable.max_deckCount; i++)
                    {
                        Variable.opponent_cards.Add(Variable.all_cardTypes[rnd.Next(1, 18)]);
                    }
                }
                else if (Variable.opponent_team == 1)
                {
                    for (int i = 0; i <= Variable.max_deckCount; i++)
                    {
                        Variable.opponent_cards.Add(Variable.all_cardTypes[rnd.Next(19, 36)]);
                    }
                }
                else if (Variable.opponent_team == 2)
                {
                    for (int i = 0; i <= Variable.max_deckCount; i++)
                    {
                        Variable.opponent_cards.Add(Variable.all_cardTypes[rnd.Next(37, 54)]);
                    }
                }
                else
                {
                    for (int i = 0; i <= Variable.max_deckCount; i++)
                    {
                        Variable.opponent_cards.Add(Variable.all_cardTypes[rnd.Next(55, 72)]);
                    }
                }
            }




            foreach (var o in Variable.opponent_cards)
            {
                Console.WriteLine("Opponent : " + o.ToString());
            }//Debugging
        }

        public void Player_Deck()
        {
                       
        }
        public void Opponent_Deck()
        {

        }

        private void PlayerDeck_PictureBox_Click(object sender, EventArgs e)
        {
            Player_DrawHand();
        }
        #endregion

        #region <-----HandManagement----->

        public void Player_DrawHand()
        {
            if(Variable.InitialSetup_Required == true)
                InitialSetup_Timer.Enabled = true;
            else
            {
                if (PlayerHand1_PictureBox.Image == null)
                {
                    PlayerHand1_PictureBox.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy_v3\GameObjects\PlayingCards\" + Variable.team_list[Variable.player_team] + @"\Card_Backside.png");
                    PlayerHand1_PictureBox.Enabled = true;
                    PlayerHand1_PictureBox.Tag = Variable.player_cards.Last();
                    Variable.player_cards.RemoveAt(Variable.player_cards.Count - 1);
                }
                    

                else if (PlayerHand2_PictureBox.Image == null)
                {
                    PlayerHand2_PictureBox.Tag = Variable.player_cards.Last();
                    Variable.player_cards.RemoveAt(Variable.player_cards.Count - 1);
                    PlayerHand2_PictureBox.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy_v3\GameObjects\PlayingCards\" + Variable.team_list[Variable.player_team] + @"\Card_Backside.png");
                    PlayerHand2_PictureBox.Enabled = true;
                }

                else if (PlayerHand3_PictureBox.Image == null)
                {
                    PlayerHand3_PictureBox.Tag = Variable.player_cards.Last();
                    Variable.player_cards.RemoveAt(Variable.player_cards.Count - 1);
                    PlayerHand3_PictureBox.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy_v3\GameObjects\PlayingCards\" + Variable.team_list[Variable.player_team] + @"\Card_Backside.png");
                    PlayerHand3_PictureBox.Enabled = true;
                }

                else if (PlayerHand4_PictureBox.Image == null)
                {
                    PlayerHand4_PictureBox.Tag = Variable.player_cards.Last();
                    Variable.player_cards.RemoveAt(Variable.player_cards.Count - 1);
                    PlayerHand4_PictureBox.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy_v3\GameObjects\PlayingCards\" + Variable.team_list[Variable.player_team] + @"\Card_Backside.png");
                    PlayerHand4_PictureBox.Enabled = true;
                }

                else if (PlayerHand5_PictureBox.Image == null)
                {
                    PlayerHand5_PictureBox.Tag = Variable.player_cards.Last();
                    Variable.player_cards.RemoveAt(Variable.player_cards.Count - 1);
                    PlayerHand5_PictureBox.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy_v3\GameObjects\PlayingCards\" + Variable.team_list[Variable.player_team] + @"\Card_Backside.png");
                    PlayerHand5_PictureBox.Enabled = true;
                }
            }
                    
        }

      
        #region <-----ClickFunction----->

        private void PlayerHand1_PictureBox_Click(object sender, EventArgs e)
        {
            PlayerHand1_SelectFunction();
        }
        private void PlayerHand1_PictureBox_DoubleClick(object sender, EventArgs e)
        {
            PlayerHand1_SelectFunction();
        }
        private void PlayerHand2_PictureBox_Click(object sender, EventArgs e)
        {
            PlayerHand2_SelectFunction();
        }
        private void PlayerHand2_PictureBox_DoubleClick(object sender, EventArgs e)
        {
            PlayerHand2_SelectFunction();
        }
        private void PlayerHand3_PictureBox_Click(object sender, EventArgs e)
        {
            PlayerHand3_SelectFunction();
        }
        private void PlayerHand3_PictureBox_DoubleClick(object sender, EventArgs e)
        {
            PlayerHand3_SelectFunction();
        }
        private void PlayerHand4_PictureBox_Click(object sender, EventArgs e)
        {
            PlayerHand4_SelectFunction();
        }
        private void PlayerHand4_PictureBox_DoubleClick(object sender, EventArgs e)
        {
            PlayerHand4_SelectFunction();
        }
        private void PlayerHand5_PictureBox_Click(object sender, EventArgs e)
        {
            PlayerHand5_SelectFunction();
        }
        private void PlayerHand5_PictureBox_DoubleClick(object sender, EventArgs e)
        {
            PlayerHand5_SelectFunction();
        }
        #endregion

        #region <-----SelectFunction----->
        public void PlayerHand1_SelectFunction()
        {
            if (Variable.player_handFlipped[0] == false)
            {
                PlayerHand1_PictureBox.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy_v3\GameObjects\PlayingCards\" + Variable.team_list[Variable.player_team] + @"\Card_Types\" + PlayerHand1_PictureBox.Tag.ToString() + ".png");
                Variable.player_handFlipped[0] = true;
            }
            else if (Variable.player_handFocused[0] == false)
            {
                PlayerHand1_PictureBox.Size = new Size(86, 146);
                PlayerHand1_PictureBox.Location = new Point(3, 3);
                Variable.player_handFocused[0] = true;

                PlayerHand2_PictureBox.Size = new Size(82, 142);
                PlayerHand3_PictureBox.Size = new Size(82, 142);
                PlayerHand4_PictureBox.Size = new Size(82, 142);
                PlayerHand5_PictureBox.Size = new Size(82, 142);
                PlayerHand2_PictureBox.Location = new Point(100, 5);
                PlayerHand3_PictureBox.Location = new Point(195, 5);
                PlayerHand4_PictureBox.Location = new Point(290, 5);
                PlayerHand5_PictureBox.Location = new Point(385, 5);
                Variable.player_handFocused[1] = false;
                Variable.player_handFocused[2] = false;
                Variable.player_handFocused[3] = false;
                Variable.player_handFocused[4] = false;

                Variable.player_handCardSelected = true;
                Variable.CurrentCardSelected = PlayerHand1_PictureBox.Tag.ToString();
            }
            else
            {
                PlayerHand1_PictureBox.Size = new Size(82, 142);
                PlayerHand1_PictureBox.Location = new Point(5, 5);
                Variable.player_handFocused[0] = false;
              
            }
        }
        public void PlayerHand2_SelectFunction()
        {
            if (Variable.player_handFlipped[1] == false)
            {
                PlayerHand2_PictureBox.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy_v3\GameObjects\PlayingCards\" + Variable.team_list[Variable.player_team] + @"\Card_Types\" + PlayerHand2_PictureBox.Tag.ToString() + ".png");
                Variable.player_handFlipped[1] = true;
            }
            else if (Variable.player_handFocused[1] == false)
            {
                PlayerHand2_PictureBox.Size = new Size(86, 146);
                PlayerHand2_PictureBox.Location = new Point(97, 3);
                Variable.player_handFocused[1] = true;

                PlayerHand1_PictureBox.Size = new Size(82, 142);
                PlayerHand3_PictureBox.Size = new Size(82, 142);
                PlayerHand4_PictureBox.Size = new Size(82, 142);
                PlayerHand5_PictureBox.Size = new Size(82, 142);
                PlayerHand1_PictureBox.Location = new Point(5, 5);
                PlayerHand3_PictureBox.Location = new Point(195, 5);
                PlayerHand4_PictureBox.Location = new Point(290, 5);
                PlayerHand5_PictureBox.Location = new Point(385, 5);
                Variable.player_handFocused[0] = false;
                Variable.player_handFocused[2] = false;
                Variable.player_handFocused[3] = false;
                Variable.player_handFocused[4] = false;

                Variable.player_handCardSelected = true;
                Variable.CurrentCardSelected = PlayerHand2_PictureBox.Tag.ToString();
            }
            else
            {
                PlayerHand2_PictureBox.Size = new Size(82, 142);
                PlayerHand2_PictureBox.Location = new Point(100, 5);
                Variable.player_handFocused[1] = false;

            }
        }
        public void PlayerHand3_SelectFunction()
        {
            if (Variable.player_handFlipped[2] == false)
            {
                PlayerHand3_PictureBox.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy_v3\GameObjects\PlayingCards\" + Variable.team_list[Variable.player_team] + @"\Card_Types\" + PlayerHand3_PictureBox.Tag.ToString() + ".png");
                Variable.player_handFlipped[2] = true;
            }
            else if (Variable.player_handFocused[2] == false)
            {
                PlayerHand3_PictureBox.Size = new Size(86, 146);
                PlayerHand3_PictureBox.Location = new Point(192, 3);
                Variable.player_handFocused[2] = true;

                PlayerHand1_PictureBox.Size = new Size(82, 142);
                PlayerHand2_PictureBox.Size = new Size(82, 142);
                PlayerHand4_PictureBox.Size = new Size(82, 142);
                PlayerHand5_PictureBox.Size = new Size(82, 142);
                PlayerHand1_PictureBox.Location = new Point(5, 5);
                PlayerHand2_PictureBox.Location = new Point(100, 5);
                PlayerHand4_PictureBox.Location = new Point(290, 5);
                PlayerHand5_PictureBox.Location = new Point(385, 5);
                Variable.player_handFocused[0] = false;
                Variable.player_handFocused[1] = false;
                Variable.player_handFocused[3] = false;
                Variable.player_handFocused[4] = false;


                Variable.player_handCardSelected = true;
                Variable.CurrentCardSelected = PlayerHand3_PictureBox.Tag.ToString();
            }
            else
            {
                PlayerHand3_PictureBox.Size = new Size(82, 142);
                PlayerHand3_PictureBox.Location = new Point(195, 5);
                Variable.player_handFocused[2] = false;

            }
        }
        public void PlayerHand4_SelectFunction()
        {
            if (Variable.player_handFlipped[3] == false)
            {
                PlayerHand4_PictureBox.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy_v3\GameObjects\PlayingCards\" + Variable.team_list[Variable.player_team] + @"\Card_Types\" + PlayerHand4_PictureBox.Tag.ToString() + ".png");
                Variable.player_handFlipped[3] = true;
            }
            else if (Variable.player_handFocused[3] == false)
            {
                PlayerHand4_PictureBox.Size = new Size(86, 146);
                PlayerHand4_PictureBox.Location = new Point(287, 3);
                Variable.player_handFocused[3] = true;

                PlayerHand1_PictureBox.Size = new Size(82, 142);
                PlayerHand2_PictureBox.Size = new Size(82, 142);
                PlayerHand3_PictureBox.Size = new Size(82, 142);
                PlayerHand5_PictureBox.Size = new Size(82, 142);
                PlayerHand1_PictureBox.Location = new Point(5, 5);
                PlayerHand2_PictureBox.Location = new Point(100, 5);
                PlayerHand3_PictureBox.Location = new Point(195, 5);
                PlayerHand5_PictureBox.Location = new Point(385, 5);
                Variable.player_handFocused[0] = false;
                Variable.player_handFocused[1] = false;
                Variable.player_handFocused[2] = false;
                Variable.player_handFocused[4] = false;


                Variable.player_handCardSelected = true;
                Variable.CurrentCardSelected = PlayerHand4_PictureBox.Tag.ToString();
            }
            else
            {
                PlayerHand4_PictureBox.Size = new Size(82, 142);
                PlayerHand4_PictureBox.Location = new Point(290, 5);
                Variable.player_handFocused[3] = false;

            }
        }
        public void PlayerHand5_SelectFunction()
        {
            if (Variable.player_handFlipped[4] == false)
            {
                PlayerHand5_PictureBox.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy_v3\GameObjects\PlayingCards\" + Variable.team_list[Variable.player_team] + @"\Card_Types\" + PlayerHand5_PictureBox.Tag.ToString() + ".png");
                Variable.player_handFlipped[4] = true;
            }
            else if (Variable.player_handFocused[4] == false)
            {
                PlayerHand5_PictureBox.Size = new Size(86, 146);
                PlayerHand5_PictureBox.Location = new Point(382, 3);
                Variable.player_handFocused[4] = true;

                PlayerHand1_PictureBox.Size = new Size(82, 142);
                PlayerHand2_PictureBox.Size = new Size(82, 142);
                PlayerHand3_PictureBox.Size = new Size(82, 142);
                PlayerHand4_PictureBox.Size = new Size(82, 142);
                PlayerHand1_PictureBox.Location = new Point(5, 5);
                PlayerHand2_PictureBox.Location = new Point(100, 5);
                PlayerHand3_PictureBox.Location = new Point(195, 5);
                PlayerHand4_PictureBox.Location = new Point(290, 5);
                Variable.player_handFocused[0] = false;
                Variable.player_handFocused[1] = false;
                Variable.player_handFocused[2] = false;
                Variable.player_handFocused[3] = false;


                Variable.player_handCardSelected = true;
                Variable.CurrentCardSelected = PlayerHand5_PictureBox.Tag.ToString();
            }
            else
            {
                PlayerHand5_PictureBox.Size = new Size(82, 142);
                PlayerHand5_PictureBox.Location = new Point(385, 5);
                Variable.player_handFocused[4] = false;


            }
        }

        #endregion

        #region <-----DeleteCards----->
        public void CardDelete()
        {
            if(Variable.CurrentCardSelected == PlayerHand1_PictureBox.Tag && Variable.player_handFocused[0] == true)
            {
                PlayerHand1_PictureBox.Image = null;
                PlayerHand1_PictureBox.Tag = null;
                PlayerHand1_PictureBox.Enabled = false;
            }
            else if (Variable.CurrentCardSelected == PlayerHand2_PictureBox.Tag && Variable.player_handFocused[1] == true)
            {
                PlayerHand2_PictureBox.Image = null;
                PlayerHand2_PictureBox.Tag = null;
                PlayerHand2_PictureBox.Enabled = false;
            }
            else if (Variable.CurrentCardSelected == PlayerHand3_PictureBox.Tag && Variable.player_handFocused[2] == true)
            {
                PlayerHand3_PictureBox.Image = null;
                PlayerHand3_PictureBox.Tag = null;
                PlayerHand3_PictureBox.Enabled = false;
            }
            else if (Variable.CurrentCardSelected == PlayerHand4_PictureBox.Tag && Variable.player_handFocused[3] == true)
            {
                PlayerHand4_PictureBox.Image = null;
                PlayerHand4_PictureBox.Tag = null;
                PlayerHand4_PictureBox.Enabled = false;
            }
            else if (Variable.CurrentCardSelected == PlayerHand5_PictureBox.Tag && Variable.player_handFocused[4] == true)
            {
                PlayerHand5_PictureBox.Image = null;
                PlayerHand5_PictureBox.Tag = null;
                PlayerHand5_PictureBox.Enabled = false;
            }
        }
        #endregion

        #endregion      

        #region <-----GameManagement----->
        public void StartGame()
        {
            BackgroundImage = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy_v3\GameObjects\Gameboard\WarefareStrategy_Gameboard.png");
            Player_GenerateDeck();
            Opponent_GenerateDeck();
            PlayerHand_Panel.Visible = true;
        }

        private void InitialSetup_Timer_Tick(object sender, EventArgs e)
        {
            if (Variable.deck_timerCounter == 1)
            {
                PlayerHand1_PictureBox.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy_v3\GameObjects\PlayingCards\" + Variable.team_list[Variable.player_team] + @"\Card_Backside.png");
                PlayerHand1_PictureBox.Enabled = true;
                PlayerHand1_PictureBox.Tag = Variable.player_cards.Last();
                Variable.player_cards.RemoveAt(Variable.player_cards.Count - 1);
            }
            else if (Variable.deck_timerCounter == 2)
            {
                PlayerHand2_PictureBox.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy_v3\GameObjects\PlayingCards\" + Variable.team_list[Variable.player_team] + @"\Card_Backside.png");
                PlayerHand2_PictureBox.Enabled = true;
                PlayerHand2_PictureBox.Tag = Variable.player_cards.Last();
                Variable.player_cards.RemoveAt(Variable.player_cards.Count - 1);
            }
            else if (Variable.deck_timerCounter == 3)
            {
                PlayerHand3_PictureBox.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy_v3\GameObjects\PlayingCards\" + Variable.team_list[Variable.player_team] + @"\Card_Backside.png");
                PlayerHand3_PictureBox.Enabled = true;
                PlayerHand3_PictureBox.Tag = Variable.player_cards.Last();
                Variable.player_cards.RemoveAt(Variable.player_cards.Count - 1);
            }
            else if (Variable.deck_timerCounter == 4)
            {
                PlayerHand4_PictureBox.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy_v3\GameObjects\PlayingCards\" + Variable.team_list[Variable.player_team] + @"\Card_Backside.png");
                PlayerHand4_PictureBox.Enabled = true;
                PlayerHand4_PictureBox.Tag = Variable.player_cards.Last();
                Variable.player_cards.RemoveAt(Variable.player_cards.Count - 1);
            }
            else if (Variable.deck_timerCounter == 5)
            {
                PlayerHand5_PictureBox.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy_v3\GameObjects\PlayingCards\" + Variable.team_list[Variable.player_team] + @"\Card_Backside.png");
                PlayerHand5_PictureBox.Enabled = true;
                PlayerHand5_PictureBox.Tag = Variable.player_cards.Last();
                Variable.player_cards.RemoveAt(Variable.player_cards.Count - 1);
                InitialSetup_Timer.Enabled = false;
            }

            Variable.deck_timerCounter += 1;
        }
        #endregion



        private void player_Slot1_Button_Click(object sender, EventArgs e)
        {

        }


















        public Form()
        {
            InitializeComponent();              
        }

#region formFunctions

        //Form functions
        private void Form_MouseHover(object sender, EventArgs e)
        {
            sett_Popup_Label.Visible = false;
            sett_Popup_Timer.Enabled = false;
        }
#endregion

#region menubuttonclick
        //Starting menu
        private void Play_Button_Click(object sender, EventArgs e)
        {
            Menu1.Visible = false;
            StartGame();
            
        }
        private void Addon_Button_Click(object sender, EventArgs e)
        {
            Menu2.Visible = true;
        }
        private void Setting_Button_Click(object sender, EventArgs e)
        {
            Menu3.Visible = true;
        }
        private void Exit_Button_Click(object sender, EventArgs e)
        {
            Close();
        }


        //Addon menu
        private void add_Timer_Button_Click(object sender, EventArgs e)
        {
            if(Variable.addon_Timer_Active == false)
            {
                add_Timer_Button.ForeColor = Color.Green;
                Variable.addon_Timer_Active = true;
            }
            else
            {
                add_Timer_Button.ForeColor = Color.Black;
                Variable.addon_Timer_Active = false;
            }
        }

        private void add_Master_Button_Click(object sender, EventArgs e)
        {
            if (Variable.addon_Master_Active == false)
            {
                add_Master_Button.ForeColor = Color.Green;
                Variable.addon_Master_Active = true;
            }
            else
            {
                add_Master_Button.ForeColor = Color.Black;
                Variable.addon_Master_Active = false;
            }
        }

        private void add_Random_Button_Click(object sender, EventArgs e)
        {
            if (Variable.addon_Random_Active == false)
            {
                add_Random_Button.ForeColor = Color.Green;
                Variable.addon_Random_Active = true;
            }
            else
            {
                add_Random_Button.ForeColor = Color.Black;
                Variable.addon_Random_Active = false;
            }
        }

        private void add_Back_Button_Click(object sender, EventArgs e)
        {
            Menu2.Visible = false;
        }


        //Setting menu
        private void sett_Sound_Button_Click(object sender, EventArgs e)
        {
            if(Variable.sett_Sound_Active == true)
            {
                sett_Sound_Button.Text = "Sound - off";
                Variable.sett_Sound_Active = false;
            }
            else
            {
                sett_Sound_Button.Text = "Sound - on";
                Variable.sett_Sound_Active = true;
            }               
        }

        private void sett_Console_Button_Click(object sender, EventArgs e)
        {
            if (Variable.sett_Console_Active == true)
            {
                sett_Console_Button.Text = "Console - off";
                Variable.sett_Console_Active = false;
            }
            else
            {
                sett_Console_Button.Text = "Console - on";
                Variable.sett_Console_Active = true;
            }
        }

        private void sett_GameSpeed_Button_Click(object sender, EventArgs e)
        {
            if (Variable.sett_GameSpeed_Value == 1)
                Variable.sett_GameSpeed_Value = 2;
            else if (Variable.sett_GameSpeed_Value == 2)
                Variable.sett_GameSpeed_Value = 3;
            else
                Variable.sett_GameSpeed_Value = 1;
            sett_GameSpeed_Button.Text = "Game-Speed - " + Variable.sett_GameSpeed_Value.ToString();
        }

        private void sett_Back_Button_Click(object sender, EventArgs e)
        {
            Menu3.Visible = false;
            sett_Popup_Label.Visible = false;
            sett_Popup_Timer.Enabled = false;
        }

        private void sett_GameSpeed_Button_MouseHover(object sender, EventArgs e)
        {
            sett_Popup_Timer.Enabled = true;
        }

        private void sett_Popup_Timer_Tick(object sender, EventArgs e)
        {
            sett_Popup_Label.Visible = true;
            sett_Popup_Timer.Enabled = false;
        }

        private void Menu3_MouseHover(object sender, EventArgs e)
        {
            sett_Popup_Label.Visible = false;
            sett_Popup_Timer.Enabled = false;
        }




        #endregion

        
    }
}
