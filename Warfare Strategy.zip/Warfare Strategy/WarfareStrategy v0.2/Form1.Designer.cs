﻿namespace WarfareStrategy_v0._2
{
    partial class GameBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(GameBoard));
            this.Timer_settingMenu = new System.Windows.Forms.Timer(this.components);
            this.bDeck = new System.Windows.Forms.PictureBox();
            this.rDeck = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.bDeck)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.rDeck)).BeginInit();
            this.SuspendLayout();
            // 
            // Timer_settingMenu
            // 
            this.Timer_settingMenu.Interval = 2000;
            // 
            // bDeck
            // 
            this.bDeck.BackColor = System.Drawing.Color.Transparent;
            this.bDeck.Location = new System.Drawing.Point(244, 676);
            this.bDeck.Name = "bDeck";
            this.bDeck.Size = new System.Drawing.Size(86, 148);
            this.bDeck.TabIndex = 0;
            this.bDeck.TabStop = false;
            // 
            // rDeck
            // 
            this.rDeck.BackColor = System.Drawing.Color.Transparent;
            this.rDeck.Location = new System.Drawing.Point(244, 2);
            this.rDeck.Name = "rDeck";
            this.rDeck.Size = new System.Drawing.Size(86, 148);
            this.rDeck.TabIndex = 1;
            this.rDeck.TabStop = false;
            // 
            // GameBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1270, 832);
            this.Controls.Add(this.rDeck);
            this.Controls.Add(this.bDeck);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "GameBoard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Game";
            this.Load += new System.EventHandler(this.GameBoard_Load);
            this.LocationChanged += new System.EventHandler(this.GameBoard_LocationChanged);
            ((System.ComponentModel.ISupportInitialize)(this.bDeck)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.rDeck)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Timer Timer_settingMenu;
        private System.Windows.Forms.PictureBox bDeck;
        private System.Windows.Forms.PictureBox rDeck;
    }
}

