﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WarfareStrategy_v0._2
{
    public partial class GameBoard : Form
    {
        public GameBoard()
        {
                InitializeComponent();
        }

        class Variables
        {
            #region Menu_Variables
            //Editing
            public static double Menu_Opacity = .75;
            //______________________MenuB_ColorArray>>{_BackColor____ForeColor_____BorderColor_}
            public static Color[] MenuB_ColorArray = { Color.Black, Color.White, Color.AliceBlue };
            #endregion

            #region Addon_Variables
            //Values
            public static bool setting_Timer_active = false;
            public static bool setting_Master_active = false;
            public static bool setting_Random_active = false;
            #endregion

            #region Game_Variables

            public const int deckMax = 25;

            public static int bDeck_CardCount = 25;
            public static int rDeck_CardCount = 25;

            public static string playerTeam = "BlueTeam";
            public static string OpponentTeam = "RedTeam";

            #endregion


        }

        #region Menu_Region
        public static Form MenuOverlay_Form = new Form();

        public static Button playButton = new Button();
        public static Button settingsButton = new Button();
        public static Button exitButton = new Button();

        public static Button setting_Timer = new Button();
        public static Button setting_Master = new Button();
        public static Button setting_Random = new Button();

        public static Label settingLabel = new Label();

        public static TextBox codeTextBox = new TextBox();


        public void Create_Menu()
        {
            int GameBoard_Width = Width;
            int GameBoard_Height = Height;

            //Background
            MenuOverlay_Form.Text = "Game";
            MenuOverlay_Form.BackColor = Color.DimGray;
            MenuOverlay_Form.Opacity = Variables.Menu_Opacity;
            MenuOverlay_Form.Size = new Size(GameBoard_Width, GameBoard_Height);
            MenuOverlay_Form.FormBorderStyle = FormBorderStyle.FixedToolWindow;
            MenuOverlay_Form.StartPosition = FormStartPosition.CenterScreen;
            MenuOverlay_Form.ShowInTaskbar = false;
            MenuOverlay_Form.MaximizeBox = false;
            MenuOverlay_Form.MinimizeBox = false;


            //Buttons
            playButton.Text = "Play";
            playButton.Size = new Size(100, 25);
            playButton.BackColor = Variables.MenuB_ColorArray[0];
            playButton.ForeColor = Variables.MenuB_ColorArray[1];
            playButton.FlatAppearance.BorderColor = Variables.MenuB_ColorArray[2];
            playButton.FlatStyle = FlatStyle.Flat;
            playButton.TabStop = false;
            playButton.Cursor = Cursors.Hand;
            playButton.Left = (Width - playButton.Width) / 2 - 7;
            playButton.Top = (Height - playButton.Height) / 2;

            settingsButton.Text = "Settings";
            settingsButton.Size = new Size(100, 25);
            settingsButton.BackColor = Variables.MenuB_ColorArray[0];
            settingsButton.ForeColor = Variables.MenuB_ColorArray[1];
            settingsButton.FlatAppearance.BorderColor = Variables.MenuB_ColorArray[2];
            settingsButton.FlatStyle = FlatStyle.Flat;
            settingsButton.TabStop = false;
            settingsButton.Cursor = Cursors.Hand;
            settingsButton.Left = (Width - settingsButton.Width) / 2 - 7;
            settingsButton.Top = (Height - settingsButton.Height) / 2 + 35;

            exitButton.Text = "Exit Game";
            exitButton.Size = new Size(100, 25);
            exitButton.BackColor = Variables.MenuB_ColorArray[0];
            exitButton.ForeColor = Variables.MenuB_ColorArray[1];
            exitButton.FlatAppearance.BorderColor = Variables.MenuB_ColorArray[2];
            exitButton.FlatStyle = FlatStyle.Flat;
            exitButton.TabStop = false;
            exitButton.Cursor = Cursors.Hand;
            exitButton.Left = (Width - exitButton.Width) / 2 - 7;
            exitButton.Top = (Height - exitButton.Height) / 2 + 70;

            //Buttons_settings_
            setting_Timer.Text = "In-Game Timer";
            setting_Timer.Size = new Size(100, 25);
            setting_Timer.BackColor = Variables.MenuB_ColorArray[0];
            setting_Timer.ForeColor = Variables.MenuB_ColorArray[1];
            setting_Timer.FlatAppearance.BorderColor = Variables.MenuB_ColorArray[2];
            setting_Timer.FlatStyle = FlatStyle.Flat;
            setting_Timer.TabStop = false;
            setting_Timer.Visible = false;
            setting_Timer.Cursor = Cursors.Hand;
            setting_Timer.Left = (Width - setting_Timer.Width) / 2 + 120;
            setting_Timer.Top = (Height - setting_Timer.Height) / 2;

            setting_Master.Text = "Master Mode";
            setting_Master.Size = new Size(100, 25);
            setting_Master.BackColor = Variables.MenuB_ColorArray[0];
            setting_Master.ForeColor = Variables.MenuB_ColorArray[1];
            setting_Master.FlatAppearance.BorderColor = Variables.MenuB_ColorArray[2];
            setting_Master.FlatStyle = FlatStyle.Flat;
            setting_Master.TabStop = false;
            setting_Master.Visible = false;
            setting_Master.Cursor = Cursors.Hand;
            setting_Master.Left = (Width - setting_Master.Width) / 2 + 120;
            setting_Master.Top = (Height - setting_Master.Height) / 2 + 35;

            setting_Random.Text = "Random Deck";
            setting_Random.Size = new Size(100, 25);
            setting_Random.BackColor = Variables.MenuB_ColorArray[0];
            setting_Random.ForeColor = Variables.MenuB_ColorArray[1];
            setting_Random.FlatAppearance.BorderColor = Variables.MenuB_ColorArray[2];
            setting_Random.FlatStyle = FlatStyle.Flat;
            setting_Random.TabStop = false;
            setting_Random.Visible = false;
            setting_Random.Cursor = Cursors.Hand;
            setting_Random.Left = (Width - setting_Random.Width) / 2 + 120;
            setting_Random.Top = (Height - setting_Random.Height) / 2 + 70;

            //Labels
            settingLabel.Text = "Settings";
            settingLabel.ForeColor = Variables.MenuB_ColorArray[0];
            settingLabel.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Regular);
            settingLabel.AutoSize = true;
            settingLabel.Visible = false;
            settingLabel.Cursor = Cursors.Hand;
            settingLabel.Left = (Width - settingLabel.Width) / 2 + 124;
            settingLabel.Top = (Height - settingLabel.Height) / 2 - 36;

            //TextBoxes
            codeTextBox.Size = new Size(100, 8);           
            codeTextBox.Location = new Point(1800,900);
            codeTextBox.BackColor = Color.DimGray;
            codeTextBox.ForeColor = Color.DimGray;
            codeTextBox.BorderStyle = BorderStyle.None;
            codeTextBox.Cursor = Cursors.Default;
            

            //Event Handlers
            MenuOverlay_Form.LocationChanged += MenuOverlay_Form_LocationChanged;
            MenuOverlay_Form.FormClosed += MenuOverlay_Form_FormClosed;
            MenuOverlay_Form.MouseHover += MenuOverlay_Form_MouseHover;
            MenuOverlay_Form.MouseClick += MenuOverlay_Form_MouseClick;

            playButton.Click += playButton_Click;
            settingsButton.Click += settingsButton_Click;
            exitButton.Click += exitButton_Click;

            setting_Timer.Click += setting_Timer_Click;
            setting_Master.Click += setting_Master_Click;
            setting_Random.Click += setting_Random_Click;

            setting_Timer.MouseHover += setting_Timer_MouseHover;
            setting_Master.MouseHover += setting_Master_MouseHover;
            setting_Random.MouseHover += setting_Random_MouseHover;

            codeTextBox.TextChanged += codeTextBox_TextChanged;

            //Objects
            MenuOverlay_Form.Controls.Add(playButton);
            MenuOverlay_Form.Controls.Add(settingsButton);
            MenuOverlay_Form.Controls.Add(exitButton);

            MenuOverlay_Form.Controls.Add(setting_Timer);
            MenuOverlay_Form.Controls.Add(setting_Master);
            MenuOverlay_Form.Controls.Add(setting_Random);

            MenuOverlay_Form.Controls.Add(settingLabel);

            MenuOverlay_Form.Controls.Add(codeTextBox);
        }
        public void Load_Menu()
        {
            MenuOverlay_Form.Show();
            MenuOverlay_Form.TopMost = true;
        }

        //Functions
        private void MenuOverlay_Form_LocationChanged(object sender, EventArgs e)
        {
            Location = new Point(MenuOverlay_Form.Location.X, MenuOverlay_Form.Location.Y);
        }
        private void MenuOverlay_Form_FormClosed(object sender, EventArgs e)
        {
            Close();
        }
        private void playButton_Click(object sender, EventArgs e)
        {
            MenuOverlay_Form.SendToBack();
        } //<------------------------------------------------------------------------------------------------------------------------Code needed
        private void settingsButton_Click(object sender, EventArgs e)
        {
            setting_Timer.Visible = true;
            setting_Master.Visible = true;
            setting_Random.Visible = true;

            settingLabel.Visible = true;

            if(Timer_settingMenu.Enabled == false)
                Timer_settingMenu.Enabled = true;

        }
        private void exitButton_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void setting_Timer_Click(object sender, EventArgs e)
        {
            if(Variables.setting_Timer_active == false)
            {
                Variables.setting_Timer_active = true;
                setting_Timer.FlatAppearance.BorderColor = Color.Gold;
            }
            else
            {
                Variables.setting_Timer_active = false;
                setting_Timer.FlatAppearance.BorderColor = Variables.MenuB_ColorArray[2];
            }
        }
        private void setting_Master_Click(object sender, EventArgs e)
        {
            if (Variables.setting_Master_active == false)
            {
                Variables.setting_Master_active = true;
                setting_Master.FlatAppearance.BorderColor = Color.Gold;
            }
            else
            {
                Variables.setting_Master_active = false;
                setting_Master.FlatAppearance.BorderColor = Variables.MenuB_ColorArray[2];
            }
        }
        private void setting_Random_Click(object sender, EventArgs e)
        {
            if (Variables.setting_Random_active == false)
            {
                Variables.setting_Random_active = true;
                setting_Random.FlatAppearance.BorderColor = Color.Gold;
            }
            else
            {
                Variables.setting_Random_active = false;
                setting_Random.FlatAppearance.BorderColor = Variables.MenuB_ColorArray[2];
            }
        }

        private void setting_Timer_MouseHover(object sender, EventArgs e)
        {
            Timer_settingMenu.Enabled = false;
        }
        private void setting_Master_MouseHover(object sender, EventArgs e)
        {
            Timer_settingMenu.Enabled = false;
        }
        private void setting_Random_MouseHover(object sender, EventArgs e)
        {
            Timer_settingMenu.Enabled = false;
        }
        private void MenuOverlay_Form_MouseHover(object sender, EventArgs e)
        {
            if(setting_Timer.Visible == true)
                Timer_settingMenu.Enabled = true;
        }
        private void Timer_settingMenu_Tick(object sender, EventArgs e)
        {
            Timer_settingMenu.Enabled = false;
            setting_Timer.Visible = false;
            setting_Master.Visible = false;
            setting_Random.Visible = false;

            settingLabel.Visible = false;
        }

        private void codeTextBox_TextChanged(object sender, EventArgs e)
        {
            if(codeTextBox.Text == "BigTiddies")
            {
                codeTextBox.Enabled = false;

            }
        }
        private void MenuOverlay_Form_MouseClick(object sender, EventArgs e)
        {
            codeTextBox.Focus();
        }

        #endregion Menu_Region

        #region GameBoard_Region

        #region Background
        private void GameBoard_Load(object sender, EventArgs e)
        {
            Create_Menu();
            Load_Menu();
            Deck_Manager();
        }

        //Functions
        private void GameBoard_LocationChanged(object sender, EventArgs e)
        {
            MenuOverlay_Form.Location = new Point(Location.X, Location.Y);
        }

        #endregion

        #region Cards
        public void Deck_Manager()
        {
            if(Variables.bDeck_CardCount >= 3)
            {
                bDeck.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy v0.2\GameObjects\PlayingCards\" + Variables.playerTeam + @"\Deck_3.png");
                bDeck.Size = new Size(86, 148);
                bDeck.Location = new Point(244, 676);
            }
            else if(Variables.bDeck_CardCount == 2)
            {
                bDeck.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy v0.2\GameObjects\PlayingCards\" + Variables.playerTeam + @"\Deck_2.png");
                bDeck.Size = new Size(84, 145);
                bDeck.Location = new Point(246, 679);
            }
            else if(Variables.bDeck_CardCount == 1)
            {
                bDeck.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy v0.2\GameObjects\PlayingCards\" + Variables.playerTeam + @"\Deck_1.png");
                bDeck.Size = new Size(82,142);
                bDeck.Location = new Point(248, 682);
            }
            else
            {
                bDeck.Image = null;
            }


            if (Variables.rDeck_CardCount >= 3)
            {
                rDeck.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy v0.2\GameObjects\PlayingCards\" + Variables.OpponentTeam + @"\Deck_3.png");
                rDeck.Size = new Size(86, 148);
                rDeck.Location = new Point(244, 2);
            }
            else if (Variables.rDeck_CardCount == 2)
            {
                rDeck.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy v0.2\GameObjects\PlayingCards\" + Variables.OpponentTeam + @"\Deck_2.png");
                rDeck.Size = new Size(84, 145);
                rDeck.Location = new Point(246, 5);
            }
            else if (Variables.rDeck_CardCount == 1)
            {
                rDeck.Image = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy v0.2\GameObjects\PlayingCards\" + Variables.OpponentTeam + @"\Deck_1.png");
                rDeck.Size = new Size(82, 142);
                rDeck.Location = new Point(248, 8);
            }
            else
            {
                rDeck.Image = null;
            }
        }

        #endregion
        #endregion

    }
}
