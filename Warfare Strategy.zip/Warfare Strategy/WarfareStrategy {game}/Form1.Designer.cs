﻿namespace WarfareStrategy__game_
{
    partial class Form
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form));
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.B_team_deck = new System.Windows.Forms.PictureBox();
            this.R_team_deck = new System.Windows.Forms.PictureBox();
            this.B_card1 = new System.Windows.Forms.Button();
            this.B_card2 = new System.Windows.Forms.Button();
            this.B_card3 = new System.Windows.Forms.Button();
            this.B_card4 = new System.Windows.Forms.Button();
            this.B_card5 = new System.Windows.Forms.Button();
            this.R_card1 = new System.Windows.Forms.Button();
            this.R_card2 = new System.Windows.Forms.Button();
            this.R_card3 = new System.Windows.Forms.Button();
            this.R_card4 = new System.Windows.Forms.Button();
            this.R_card5 = new System.Windows.Forms.Button();
            this.Deck_Count_label = new System.Windows.Forms.Label();
            this.DevTool_listbox = new System.Windows.Forms.ListBox();
            this.Dealing_Timer = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.B_team_deck)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.R_team_deck)).BeginInit();
            this.SuspendLayout();
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            // 
            // B_team_deck
            // 
            this.B_team_deck.Image = ((System.Drawing.Image)(resources.GetObject("B_team_deck.Image")));
            this.B_team_deck.Location = new System.Drawing.Point(14, 523);
            this.B_team_deck.Name = "B_team_deck";
            this.B_team_deck.Size = new System.Drawing.Size(37, 63);
            this.B_team_deck.TabIndex = 0;
            this.B_team_deck.TabStop = false;
            // 
            // R_team_deck
            // 
            this.R_team_deck.Image = ((System.Drawing.Image)(resources.GetObject("R_team_deck.Image")));
            this.R_team_deck.Location = new System.Drawing.Point(549, 14);
            this.R_team_deck.Name = "R_team_deck";
            this.R_team_deck.Size = new System.Drawing.Size(37, 63);
            this.R_team_deck.TabIndex = 1;
            this.R_team_deck.TabStop = false;
            // 
            // B_card1
            // 
            this.B_card1.BackColor = System.Drawing.Color.Transparent;
            this.B_card1.Cursor = System.Windows.Forms.Cursors.Default;
            this.B_card1.FlatAppearance.BorderSize = 0;
            this.B_card1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.B_card1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.B_card1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_card1.Location = new System.Drawing.Point(95, 523);
            this.B_card1.Name = "B_card1";
            this.B_card1.Size = new System.Drawing.Size(37, 63);
            this.B_card1.TabIndex = 13;
            this.B_card1.UseVisualStyleBackColor = false;
            this.B_card1.Click += new System.EventHandler(this.B_card1_Click);
            // 
            // B_card2
            // 
            this.B_card2.BackColor = System.Drawing.Color.Transparent;
            this.B_card2.FlatAppearance.BorderSize = 0;
            this.B_card2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.B_card2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.B_card2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_card2.Location = new System.Drawing.Point(136, 523);
            this.B_card2.Name = "B_card2";
            this.B_card2.Size = new System.Drawing.Size(37, 63);
            this.B_card2.TabIndex = 14;
            this.B_card2.UseVisualStyleBackColor = false;
            this.B_card2.Click += new System.EventHandler(this.B_card2_Click);
            // 
            // B_card3
            // 
            this.B_card3.BackColor = System.Drawing.Color.Transparent;
            this.B_card3.FlatAppearance.BorderSize = 0;
            this.B_card3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.B_card3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.B_card3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_card3.Location = new System.Drawing.Point(177, 523);
            this.B_card3.Name = "B_card3";
            this.B_card3.Size = new System.Drawing.Size(37, 63);
            this.B_card3.TabIndex = 15;
            this.B_card3.UseVisualStyleBackColor = false;
            this.B_card3.Click += new System.EventHandler(this.B_card3_Click);
            // 
            // B_card4
            // 
            this.B_card4.BackColor = System.Drawing.Color.Transparent;
            this.B_card4.FlatAppearance.BorderSize = 0;
            this.B_card4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.B_card4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.B_card4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_card4.Location = new System.Drawing.Point(218, 523);
            this.B_card4.Name = "B_card4";
            this.B_card4.Size = new System.Drawing.Size(37, 63);
            this.B_card4.TabIndex = 16;
            this.B_card4.UseVisualStyleBackColor = false;
            this.B_card4.Click += new System.EventHandler(this.B_card4_Click);
            // 
            // B_card5
            // 
            this.B_card5.BackColor = System.Drawing.Color.Transparent;
            this.B_card5.FlatAppearance.BorderSize = 0;
            this.B_card5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.B_card5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.B_card5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.B_card5.Location = new System.Drawing.Point(259, 523);
            this.B_card5.Name = "B_card5";
            this.B_card5.Size = new System.Drawing.Size(37, 63);
            this.B_card5.TabIndex = 17;
            this.B_card5.UseVisualStyleBackColor = false;
            this.B_card5.Click += new System.EventHandler(this.B_card5_Click);
            // 
            // R_card1
            // 
            this.R_card1.BackColor = System.Drawing.Color.Transparent;
            this.R_card1.FlatAppearance.BorderSize = 0;
            this.R_card1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.R_card1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.R_card1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.R_card1.Location = new System.Drawing.Point(468, 14);
            this.R_card1.Name = "R_card1";
            this.R_card1.Size = new System.Drawing.Size(37, 63);
            this.R_card1.TabIndex = 22;
            this.R_card1.UseVisualStyleBackColor = false;
            this.R_card1.Click += new System.EventHandler(this.R_card1_Click);
            // 
            // R_card2
            // 
            this.R_card2.BackColor = System.Drawing.Color.Transparent;
            this.R_card2.FlatAppearance.BorderSize = 0;
            this.R_card2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.R_card2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.R_card2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.R_card2.Location = new System.Drawing.Point(427, 14);
            this.R_card2.Name = "R_card2";
            this.R_card2.Size = new System.Drawing.Size(37, 63);
            this.R_card2.TabIndex = 21;
            this.R_card2.UseVisualStyleBackColor = false;
            this.R_card2.Click += new System.EventHandler(this.R_card2_Click);
            // 
            // R_card3
            // 
            this.R_card3.BackColor = System.Drawing.Color.Transparent;
            this.R_card3.FlatAppearance.BorderSize = 0;
            this.R_card3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.R_card3.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.R_card3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.R_card3.Location = new System.Drawing.Point(386, 14);
            this.R_card3.Name = "R_card3";
            this.R_card3.Size = new System.Drawing.Size(37, 63);
            this.R_card3.TabIndex = 20;
            this.R_card3.UseVisualStyleBackColor = false;
            this.R_card3.Click += new System.EventHandler(this.R_card3_Click);
            // 
            // R_card4
            // 
            this.R_card4.BackColor = System.Drawing.Color.Transparent;
            this.R_card4.FlatAppearance.BorderSize = 0;
            this.R_card4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.R_card4.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.R_card4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.R_card4.Location = new System.Drawing.Point(345, 14);
            this.R_card4.Name = "R_card4";
            this.R_card4.Size = new System.Drawing.Size(37, 63);
            this.R_card4.TabIndex = 19;
            this.R_card4.UseVisualStyleBackColor = false;
            this.R_card4.Click += new System.EventHandler(this.R_card4_Click);
            // 
            // R_card5
            // 
            this.R_card5.BackColor = System.Drawing.Color.Transparent;
            this.R_card5.FlatAppearance.BorderSize = 0;
            this.R_card5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.R_card5.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.R_card5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.R_card5.Location = new System.Drawing.Point(304, 14);
            this.R_card5.Name = "R_card5";
            this.R_card5.Size = new System.Drawing.Size(37, 63);
            this.R_card5.TabIndex = 18;
            this.R_card5.UseVisualStyleBackColor = false;
            this.R_card5.Click += new System.EventHandler(this.R_card5_Click);
            // 
            // Deck_Count_label
            // 
            this.Deck_Count_label.AutoSize = true;
            this.Deck_Count_label.Location = new System.Drawing.Point(23, 507);
            this.Deck_Count_label.Name = "Deck_Count_label";
            this.Deck_Count_label.Size = new System.Drawing.Size(19, 13);
            this.Deck_Count_label.TabIndex = 23;
            this.Deck_Count_label.Text = "15";
            // 
            // DevTool_listbox
            // 
            this.DevTool_listbox.AllowDrop = true;
            this.DevTool_listbox.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.DevTool_listbox.FormattingEnabled = true;
            this.DevTool_listbox.Items.AddRange(new object[] {
            "Deal Hand",
            "Reset Board",
            "Shuffle Deck"});
            this.DevTool_listbox.Location = new System.Drawing.Point(482, 558);
            this.DevTool_listbox.Name = "DevTool_listbox";
            this.DevTool_listbox.Size = new System.Drawing.Size(106, 30);
            this.DevTool_listbox.TabIndex = 24;
            this.DevTool_listbox.SelectedIndexChanged += new System.EventHandler(this.DevTool_listbox_SelectedIndexChanged);
            // 
            // Dealing_Timer
            // 
            this.Dealing_Timer.Interval = 230;
            this.Dealing_Timer.Tick += new System.EventHandler(this.Dealing_Timer_Tick);
            // 
            // Form
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(600, 600);
            this.Controls.Add(this.DevTool_listbox);
            this.Controls.Add(this.Deck_Count_label);
            this.Controls.Add(this.R_card1);
            this.Controls.Add(this.R_card2);
            this.Controls.Add(this.R_card3);
            this.Controls.Add(this.R_card4);
            this.Controls.Add(this.R_card5);
            this.Controls.Add(this.B_card5);
            this.Controls.Add(this.B_card4);
            this.Controls.Add(this.B_card3);
            this.Controls.Add(this.B_card2);
            this.Controls.Add(this.B_card1);
            this.Controls.Add(this.R_team_deck);
            this.Controls.Add(this.B_team_deck);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Name = "Form";
            this.Text = "Game";
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.B_team_deck)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.R_team_deck)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.IO.FileSystemWatcher fileSystemWatcher1;
        private System.Windows.Forms.PictureBox R_team_deck;
        private System.Windows.Forms.PictureBox B_team_deck;
        private System.Windows.Forms.Button B_card1;
        private System.Windows.Forms.Button B_card5;
        private System.Windows.Forms.Button B_card4;
        private System.Windows.Forms.Button B_card3;
        private System.Windows.Forms.Button B_card2;
        private System.Windows.Forms.Button R_card1;
        private System.Windows.Forms.Button R_card2;
        private System.Windows.Forms.Button R_card3;
        private System.Windows.Forms.Button R_card4;
        private System.Windows.Forms.Button R_card5;
        private System.Windows.Forms.Label Deck_Count_label;
        private System.Windows.Forms.ListBox DevTool_listbox;
        private System.Windows.Forms.Timer Dealing_Timer;
    }
}

