﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WarfareStrategy__game_
{
    public partial class Form : System.Windows.Forms.Form
    {
        public Form()
        {
            InitializeComponent();
        }

        //Variables {Card_Images}
        public const string deckImage_BACK_BLUE = @"C:\Users\14698\source\repos\WarfareStrategy {game}\Game Objects\Blue Team\Cards\B_team_deck.png"; //For easy image swapping
        public const string deckImage_BACK_RED = @"C:\Users\14698\source\repos\WarfareStrategy {game}\Game Objects\Red Team\Cards\R_team_deck.png"; //For easy image swapping


        //Vairables {Deal_Hand}
        public int deckCount_BLUE = 15; //reset
        public int deckCount_RED = 15; //reset
        public const int maxCardNum = 4; // The number of cards available to choose from

        public string[] cardType_perSlot_BLUE = { "", "", "", "", "" }; //reset
        public string[] cardType_perSlot_RED = { "", "", "", "", "" }; //reset

        public void Deal_Hand()
        {
            if (cardSlot == 1)
            {
                B_card1.BackgroundImage = Image.FromFile(deckImage_BACK_BLUE);
                B_card1.Cursor = Cursors.Hand;

                Random rnd = new Random(Guid.NewGuid().GetHashCode());
                cardType_perSlot_BLUE[0] = rnd.Next(1, maxCardNum).ToString(); //Picks a random card to allocate to button 1
            }               
            else if(cardSlot == 2)
            {
                B_card2.BackgroundImage = Image.FromFile(deckImage_BACK_BLUE);
                B_card2.Cursor = Cursors.Hand;

                Random rnd = new Random(Guid.NewGuid().GetHashCode());
                cardType_perSlot_BLUE[1] = rnd.Next(1, maxCardNum).ToString(); //Picks a random card to allocate to button 2
            }               
            else if (cardSlot == 3)
            {
                B_card3.BackgroundImage = Image.FromFile(deckImage_BACK_BLUE);
                B_card3.Cursor = Cursors.Hand;

                Random rnd = new Random(Guid.NewGuid().GetHashCode());
                cardType_perSlot_BLUE[2] = rnd.Next(1, maxCardNum).ToString(); //Picks a random card to allocate to button 3
            }              
            else if (cardSlot == 4)
            {
                B_card4.BackgroundImage = Image.FromFile(deckImage_BACK_BLUE);
                B_card4.Cursor = Cursors.Hand;

                Random rnd = new Random(Guid.NewGuid().GetHashCode());
                cardType_perSlot_BLUE[3] = rnd.Next(1, maxCardNum).ToString(); //Picks a random card to allocate to button 4
            }  
            else if (cardSlot == 5)
            {
                B_card5.BackgroundImage = Image.FromFile(deckImage_BACK_BLUE);
                B_card5.Cursor = Cursors.Hand;

                Random rnd = new Random(Guid.NewGuid().GetHashCode());
                cardType_perSlot_BLUE[4] = rnd.Next(1, maxCardNum).ToString(); //Picks a random card to allocate to button 5
            }


            if (cardSlot == 1)
            {
                R_card1.BackgroundImage = Image.FromFile(deckImage_BACK_RED);
                R_card1.Cursor = Cursors.Hand;

                Random rnd = new Random(Guid.NewGuid().GetHashCode());
                cardType_perSlot_RED[0] = rnd.Next(1, maxCardNum).ToString(); //Picks a random card to allocate to button 1
            }
            else if (cardSlot == 2)
            {
                R_card2.BackgroundImage = Image.FromFile(deckImage_BACK_RED);
                R_card2.Cursor = Cursors.Hand;

                Random rnd = new Random(Guid.NewGuid().GetHashCode());
                cardType_perSlot_RED[1] = rnd.Next(1, maxCardNum).ToString(); //Picks a random card to allocate to button 2
            }
            else if (cardSlot == 3)
            {
                R_card3.BackgroundImage = Image.FromFile(deckImage_BACK_RED);
                R_card3.Cursor = Cursors.Hand;

                Random rnd = new Random(Guid.NewGuid().GetHashCode());
                cardType_perSlot_RED[2] = rnd.Next(1, maxCardNum).ToString(); //Picks a random card to allocate to button 3
            }
            else if (cardSlot == 4)
            {
                R_card4.BackgroundImage = Image.FromFile(deckImage_BACK_RED);
                R_card4.Cursor = Cursors.Hand;

                Random rnd = new Random(Guid.NewGuid().GetHashCode());
                cardType_perSlot_RED[3] = rnd.Next(1, maxCardNum).ToString(); //Picks a random card to allocate to button 4
            }
            else if (cardSlot == 5)
            {
                R_card5.BackgroundImage = Image.FromFile(deckImage_BACK_RED);
                R_card5.Cursor = Cursors.Hand;

                Random rnd = new Random(Guid.NewGuid().GetHashCode());
                cardType_perSlot_RED[4] = rnd.Next(1, maxCardNum).ToString(); //Picks a random card to allocate to button 5
            }          
        }

        //Variables {Dealing_Timer}
        public int cardSlot = 1; //reset
        private void Dealing_Timer_Tick(object sender, EventArgs e)
        {            
            if(cardSlot > 5)
            {
                Dealing_Timer.Enabled = false;
            }
            else
            {
                Deal_Hand();
                deckCount_BLUE--;
                deckCount_RED--;
                Deck_Count_label.Text = deckCount_BLUE.ToString();
                cardSlot++;
            }           
        }















        //Variables {Times a button has been pressed} 
        public string[] buttonPressed_BLUE = { "0", "0", "0", "0", "0" }; //reset

        //----------------------------------------------------
        private void B_card1_Click(object sender, EventArgs e)
        {
            if(buttonPressed_BLUE[0] == "0")
            {
                buttonPressed_BLUE[0] = "1";
                B_card1.BackgroundImage = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy {game}\Game Objects\Blue Team\Cards\" + cardType_perSlot_BLUE[0] + ".png");
            }
            else
            {
                B_card1.Enabled = false;
                B_card1.BackgroundImage = null;
            }
        }

        private void B_card2_Click(object sender, EventArgs e)
        {
            if (buttonPressed_BLUE[1] == "0")
            {
                buttonPressed_BLUE[1] = "1";
                B_card2.BackgroundImage = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy {game}\Game Objects\Blue Team\Cards\" + cardType_perSlot_BLUE[1] + ".png");
            }
            else
            {
                B_card2.Enabled = false;
                B_card2.BackgroundImage = null;
            }
        }

        private void B_card3_Click(object sender, EventArgs e)
        {
            if (buttonPressed_BLUE[2] == "0")
            {
                buttonPressed_BLUE[2] = "1";
                B_card3.BackgroundImage = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy {game}\Game Objects\Blue Team\Cards\" + cardType_perSlot_BLUE[2] + ".png");
            }
            else
            {
                B_card3.Enabled = false;
                B_card3.BackgroundImage = null;
            }
        }

        private void B_card4_Click(object sender, EventArgs e)
        {
            if (buttonPressed_BLUE[3] == "0")
            {
                buttonPressed_BLUE[3] = "1";
                B_card4.BackgroundImage = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy {game}\Game Objects\Blue Team\Cards\" + cardType_perSlot_BLUE[3] + ".png");
            }
            else
            {
                B_card4.Enabled = false;
                B_card4.BackgroundImage = null;
            }
        }

        private void B_card5_Click(object sender, EventArgs e)
        {
            if (buttonPressed_BLUE[4] == "0")
            {
                buttonPressed_BLUE[4] = "1";
                B_card5.BackgroundImage = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy {game}\Game Objects\Blue Team\Cards\" + cardType_perSlot_BLUE[4] + ".png");
            }
            else
            {
                B_card5.Enabled = false;
                B_card5.BackgroundImage = null;
            }
        }
        //----------------------------------------------------

        public int buttonsPressed = 0; //reset
        public string[] buttonClicked = { "0", "0", "0", "0", "0" }; //reset
        //----------------------------------------------------
        private void R_card1_Click(object sender, EventArgs e)
        {
            if(buttonsPressed < 2 && buttonClicked[0] != "1")
            {               
                R_card1.Cursor = Cursors.Default;
                R_card1.BackgroundImage = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy {game}\Game Objects\Red Team\Cards\" + cardType_perSlot_RED[0] + ".png");
                buttonsPressed++;
                buttonClicked[0] = "1";
            }
            if(buttonsPressed == 2)
            {
                R_card1.Cursor = Cursors.Default;
                R_card2.Cursor = Cursors.Default;
                R_card3.Cursor = Cursors.Default;
                R_card4.Cursor = Cursors.Default;
                R_card5.Cursor = Cursors.Default;
            }          
        }

        private void R_card2_Click(object sender, EventArgs e)
        {
            if (buttonsPressed < 2 && buttonClicked[1] != "1")
            {
                R_card2.Cursor = Cursors.Default;
                R_card2.BackgroundImage = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy {game}\Game Objects\Red Team\Cards\" + cardType_perSlot_RED[1] + ".png");
                buttonsPressed++;
                buttonClicked[1] = "1";
            }
            if (buttonsPressed == 2)
            {
                R_card1.Cursor = Cursors.Default;
                R_card2.Cursor = Cursors.Default;
                R_card3.Cursor = Cursors.Default;
                R_card4.Cursor = Cursors.Default;
                R_card5.Cursor = Cursors.Default;
            }
        }

        private void R_card3_Click(object sender, EventArgs e)
        {
            if (buttonsPressed < 2 && buttonClicked[2] != "1")
            {
                R_card3.Cursor = Cursors.Default;
                R_card3.BackgroundImage = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy {game}\Game Objects\Red Team\Cards\" + cardType_perSlot_RED[2] + ".png");
                buttonsPressed++;
                buttonClicked[2] = "1";
            }
            if (buttonsPressed == 2)
            {
                R_card1.Cursor = Cursors.Default;
                R_card2.Cursor = Cursors.Default;
                R_card3.Cursor = Cursors.Default;
                R_card4.Cursor = Cursors.Default;
                R_card5.Cursor = Cursors.Default;
            }
        }

        private void R_card4_Click(object sender, EventArgs e)
        {
            if (buttonsPressed < 2 && buttonClicked[3] != "1")
            {
                R_card4.Cursor = Cursors.Default;
                R_card4.BackgroundImage = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy {game}\Game Objects\Red Team\Cards\" + cardType_perSlot_RED[3] + ".png");
                buttonsPressed++;
                buttonClicked[3] = "1";
            }
            if (buttonsPressed == 2 )
            {
                R_card1.Cursor = Cursors.Default;
                R_card2.Cursor = Cursors.Default;
                R_card3.Cursor = Cursors.Default;
                R_card4.Cursor = Cursors.Default;
                R_card5.Cursor = Cursors.Default;
            }
        }

        private void R_card5_Click(object sender, EventArgs e)
        {
            if (buttonsPressed < 2 && buttonClicked[4] != "1")
            {
                R_card5.Cursor = Cursors.Default;
                R_card5.BackgroundImage = Image.FromFile(@"C:\Users\14698\source\repos\WarfareStrategy {game}\Game Objects\Red Team\Cards\" + cardType_perSlot_RED[4] + ".png");
                buttonsPressed++;
                buttonClicked[4] = "1";
            }
            if (buttonsPressed == 2)
            {
                R_card1.Cursor = Cursors.Default;
                R_card2.Cursor = Cursors.Default;
                R_card3.Cursor = Cursors.Default;
                R_card4.Cursor = Cursors.Default;
                R_card5.Cursor = Cursors.Default;
            }
        }
        //----------------------------------------------------


        private void DevTool_listbox_SelectedIndexChanged(object sender, EventArgs e)
        {
            if(DevTool_listbox.SelectedItem == "Deal Hand")
            {
                Dealing_Timer.Enabled = true;
            }
        }

        
    }
}
