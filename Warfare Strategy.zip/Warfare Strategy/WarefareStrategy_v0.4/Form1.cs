﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WarefareStrategy_v0._4
{
    public partial class Boardgame : Form
    {
        public Boardgame()
        {
            InitializeComponent();
        }


        #region <-----Menu----->
        //_____________________________________________________________Menu-1___
        private void Play_Button_Click(object sender, EventArgs e)
        {
            Menu1.Visible = false;
            Build_CardSelectionMenu();
        }

        private void Addon_Button_Click(object sender, EventArgs e)
        {
            Menu2.Visible = true;
        }

        private void Setting_Button_Click(object sender, EventArgs e)
        {
            Menu3.Visible = true;
        }

        private void Exit_Button_Click(object sender, EventArgs e)
        {
            Close();
        }

        //_____________________________________________________________Menu-2___
        private void add_Timer_Button_Click(object sender, EventArgs e)
        {
            if (Addon_Manager.addons_Timer_Active == false)
            {
                add_Timer_Button.ForeColor = Color.Green;
                Addon_Manager.addons_Timer_Active = true;
                Addon_Manager.addons_ActiveCount++;
            }
            else
            {
                add_Timer_Button.ForeColor = Color.Black;
                Addon_Manager.addons_Timer_Active = false;
                Addon_Manager.addons_ActiveCount--;
            }
        }

        private void add_Random_Button_Click(object sender, EventArgs e)
        {
            if (Addon_Manager.addons_Random_Active == false)
            {
                add_Random_Button.ForeColor = Color.Green;
                Addon_Manager.addons_Random_Active = true;
                Addon_Manager.addons_ActiveCount++;
            }
            else
            {
                add_Random_Button.ForeColor = Color.Black;
                Addon_Manager.addons_Random_Active = false;
                Addon_Manager.addons_ActiveCount--;
            }
        }
        private void add_Master_Button_Click(object sender, EventArgs e)
        {
            if (Addon_Manager.addons_Master_Active == false)
            {
                add_Master_Button.ForeColor = Color.Green;
                Addon_Manager.addons_Master_Active = true;
                Addon_Manager.addons_ActiveCount++;
            }
            else
            {
                add_Master_Button.ForeColor = Color.Black;
                Addon_Manager.addons_Master_Active = false;
                Addon_Manager.addons_ActiveCount--;
            }
        }

        private void add_Back_Button_Click(object sender, EventArgs e)
        {
            Menu2.Visible = false;
        }

        //_____________________________________________________________Menu-3___
        private void sett_Sound_Button_Click(object sender, EventArgs e)
        {
            if (Setting_Manager.settings_Sound_Active == true)
            {
                sett_Sound_Button.Text = "Sound - off";
                Setting_Manager.settings_Sound_Active = false;
            }
            else
            {
                sett_Sound_Button.Text = "Sound - on";
                Setting_Manager.settings_Sound_Active = true;
            }
        }

        private void sett_GameSpeed_Button_Click(object sender, EventArgs e)
        {
            if (Setting_Manager.settings_GameSpeed_Value < 3)
                Setting_Manager.settings_GameSpeed_Value++;
            else
                Setting_Manager.settings_GameSpeed_Value = 1;
            sett_GameSpeed_Button.Text = "Game-Speed - " + Setting_Manager.settings_GameSpeed_Value.ToString();
        }

        private void sett_Console_Button_Click(object sender, EventArgs e)
        {
            if (Setting_Manager.settings_Console_Active == true)
            {
                sett_Console_Button.Text = "Console - off";
                Setting_Manager.settings_Console_Active = false;
            }
            else
            {
                sett_Console_Button.Text = "Console - on";
                Setting_Manager.settings_Console_Active = true;
            }
        }

        private void sett_Back_Button_Click(object sender, EventArgs e)
        {
            Menu3.Visible = false;
            sett_Popup_Label.Visible = false;
            sett_Popup_Timer.Enabled = false;
        }

        private void sett_GameSpeed_Button_MouseHover(object sender, EventArgs e)
        {
            sett_Popup_Timer.Enabled = true;
        }

        private void sett_GameSpeed_Button_MouseLeave(object sender, EventArgs e)
        {
            sett_Popup_Label.Visible = false;
            sett_Popup_Timer.Enabled = false;
        }

        private void sett_Popup_Timer_Tick(object sender, EventArgs e)
        {
            sett_Popup_Label.Visible = true;
            sett_Popup_Timer.Enabled = false;
        }
        #endregion

        #region <-----Menu2----->
        public void Build_CardSelectionMenu()
        {
            if(Players_Manager.P1_Team == "BlueTeam")
            {

            }
            BackgroundImage = Image.FromFile(@"C:\Users\14698\source\repos\WarefareStrategy_v0.4\Resources\Boardgame\Background\WarefareStrategy_Menu2_Singleplayer.png");
            Update_Menu2();            
            P1Selection_Panel.Visible = true;
        }

        public void Update_Menu2()
        {
            #region Update Labels
            /// Addons
            p1_Addons_Label.Text = "Addons: " + Addon_Manager.addons_ActiveCount;
            if (Addon_Manager.addons_Timer_Active is true)
                p1_Timer_Label.Text = "Timer: on";
            else
                p1_Timer_Label.Text = "Timer: off";
            if (Addon_Manager.addons_Master_Active is true)
                p1_Master_Label.Text = "Master: on";
            else
                p1_Master_Label.Text = "Master: off";
            if (Addon_Manager.addons_Random_Active is true)
                p1_Random_Label.Text = "Random: on";
            else
                p1_Random_Label.Text = "Random: off";

            /// Settings
            if (Setting_Manager.settings_Sound_Active is true)
                p1_Sound_Label.Text = "Sound: on";
            else
                p1_Sound_Label.Text = "Sound: off";
            if (Setting_Manager.settings_Sound_Active is true)
                p1_Console_Label.Text = "Console: on";
            else
                p1_Console_Label.Text = "Console: off";
            p1_Difficulty_Label.Text = "Difficulty: " + Setting_Manager.difficulty;
            p1_Team_Label.Text = "Team: " + Players_Manager.P1_Team.Replace("Team", "");
            /// Deck Statistics
            CardMenuVariables.p1_CardCount = CardMenuVariables.p1_MeleeCardCount + CardMenuVariables.p1_RangeCardCount + CardMenuVariables.p1_SpecialCardCount;
            p1_Units_Label.Text = "Units: " + CardMenuVariables.p1_CardCount;
            p1_Melee_Label.Text = "Melee: " + CardMenuVariables.p1_MeleeCardCount;
            p1_Range_Label.Text = "Range: " + CardMenuVariables.p1_RangeCardCount;
            p1_Special_Label.Text = "Special: " + CardMenuVariables.p1_SpecialCardCount;

            /// Game Statistics


            #endregion

            #region Update Cards
            /// <summary>
            /// This region contains the code that changes the positioning of the Buttons for the deck
            /// </summary>


            #endregion
        }

        #region p1_DeckCreator  
        #region Slot 1
        private void Player1_CardSlot1_click(object sender, EventArgs e)
        {
            /// Button setup            
            Button p1_CardType1 = new Button
            {
                Parent = P1Selection_Panel,
                Size = new Size(220, 23),
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.DarkGray,
                TextAlign = ContentAlignment.MiddleLeft,
                Text = Player1_CardSlot1.Text,
                FlatAppearance = { BorderSize = 0, MouseDownBackColor = Color.Transparent, MouseOverBackColor = Color.Black },
                Location = new Point(386, CardMenuVariables.p1_yPos - (CardMenuVariables.p1_CardType2Count + 1 + CardMenuVariables.p1_CardType3Count + 1 + CardMenuVariables.p1_CardType4Count + 1 + CardMenuVariables.p1_CardType5Count + 1 + CardMenuVariables.p1_CardType6Count + 1) * 22)
            };

            p1_CardType1.MouseClick += p1_CardType1_Click; ///Button click event
            CardMenuVariables.p1_CardType1List.Add(p1_CardType1);
            CardMenuVariables.p1_CardType1Count++;
            CardMenuVariables.p1_yPos += 22;

            Update_Menu2();

            /// Button Location change
            foreach (Button i in CardMenuVariables.p1_CardType2List)
            {
                i.Location = new Point(386, i.Location.Y + 22);
            }
            foreach (Button i in CardMenuVariables.p1_CardType3List)
            {
                i.Location = new Point(386, i.Location.Y + 22);
            }
            foreach (Button i in CardMenuVariables.p1_CardType4List)
            {
                i.Location = new Point(386, i.Location.Y + 22);
            }
            foreach (Button i in CardMenuVariables.p1_CardType5List)
            {
                i.Location = new Point(386, i.Location.Y + 22);
            }
            foreach (Button i in CardMenuVariables.p1_CardType6List)
            {
                i.Location = new Point(386, i.Location.Y + 22);
            }
        }
        private void p1_CardType1_Click(object sender, EventArgs e)
        {
            CardMenuVariables.p1_CardType1List[CardMenuVariables.p1_CardType1Count].Dispose();
            CardMenuVariables.p1_CardType1List.RemoveAt(CardMenuVariables.p1_CardType1Count);
            CardMenuVariables.p1_CardType1Count--;
            CardMenuVariables.p1_yPos -= 22;

            Update_Menu2();

            /// Button Location change
            foreach (Button i in CardMenuVariables.p1_CardType2List)
            {
                i.Location = new Point(386, i.Location.Y - 22);
            }
            foreach (Button i in CardMenuVariables.p1_CardType3List)
            {
                i.Location = new Point(386, i.Location.Y - 22);
            }
            foreach (Button i in CardMenuVariables.p1_CardType4List)
            {
                i.Location = new Point(386, i.Location.Y - 22);
            }
            foreach (Button i in CardMenuVariables.p1_CardType5List)
            {
                i.Location = new Point(386, i.Location.Y - 22);
            }
            foreach (Button i in CardMenuVariables.p1_CardType6List)
            {
                i.Location = new Point(386, i.Location.Y - 22);
            }
        }
        #endregion
        #region Slot 2
        private void Player1_CardSlot2_Click(object sender, EventArgs e)
        {
            /// Button setup            
            Button p1_CardType2 = new Button
            {
                Parent = P1Selection_Panel,
                Size = new Size(220, 23),
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.DarkGray,
                TextAlign = ContentAlignment.MiddleLeft,
                Text = Player1_CardSlot2.Text,
                FlatAppearance = { BorderSize = 0, MouseDownBackColor = Color.Transparent, MouseOverBackColor = Color.Black },
                Location = new Point(386, CardMenuVariables.p1_yPos - (CardMenuVariables.p1_CardType3Count + 1 + CardMenuVariables.p1_CardType4Count + 1 + CardMenuVariables.p1_CardType5Count + 1 + CardMenuVariables.p1_CardType6Count + 1) * 22)
            };

            p1_CardType2.MouseClick += p1_CardType2_Click; ///Button click event
            CardMenuVariables.p1_CardType2List.Add(p1_CardType2);
            CardMenuVariables.p1_CardType2Count++;
            CardMenuVariables.p1_yPos += 22;

            Update_Menu2();

            /// Button Location change
            foreach (Button i in CardMenuVariables.p1_CardType3List)
            {
                i.Location = new Point(386, i.Location.Y + 22);
            }
            foreach (Button i in CardMenuVariables.p1_CardType4List)
            {
                i.Location = new Point(386, i.Location.Y + 22);
            }
            foreach (Button i in CardMenuVariables.p1_CardType5List)
            {
                i.Location = new Point(386, i.Location.Y + 22);
            }
            foreach (Button i in CardMenuVariables.p1_CardType6List)
            {
                i.Location = new Point(386, i.Location.Y + 22);
            }
        }
        private void p1_CardType2_Click(object sender, EventArgs e)
        {
            CardMenuVariables.p1_CardType2List[CardMenuVariables.p1_CardType2Count].Dispose();
            CardMenuVariables.p1_CardType2List.RemoveAt(CardMenuVariables.p1_CardType2Count);
            CardMenuVariables.p1_CardType2Count--;
            CardMenuVariables.p1_yPos -= 22;

            Update_Menu2();

            /// Button Location change
            foreach (Button i in CardMenuVariables.p1_CardType3List)
            {
                i.Location = new Point(386, i.Location.Y - 22);
            }
            foreach (Button i in CardMenuVariables.p1_CardType4List)
            {
                i.Location = new Point(386, i.Location.Y - 22);
            }
            foreach (Button i in CardMenuVariables.p1_CardType5List)
            {
                i.Location = new Point(386, i.Location.Y - 22);
            }
            foreach (Button i in CardMenuVariables.p1_CardType6List)
            {
                i.Location = new Point(386, i.Location.Y - 22);
            }
        }
        #endregion
        #region Slot 3
        private void Player1_CardSlot3_click(object sender, EventArgs e)
        {
            /// Button setup            
            Button p1_CardType3 = new Button
            {
                Parent = P1Selection_Panel,
                Size = new Size(220, 23),
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.DarkGray,
                TextAlign = ContentAlignment.MiddleLeft,
                Text = Player1_CardSlot3.Text,
                FlatAppearance = { BorderSize = 0, MouseDownBackColor = Color.Transparent, MouseOverBackColor = Color.Black },
                Location = new Point(386, CardMenuVariables.p1_yPos - (CardMenuVariables.p1_CardType4Count + 1 + CardMenuVariables.p1_CardType5Count + 1 + CardMenuVariables.p1_CardType6Count + 1) * 22)
            };

            p1_CardType3.MouseClick += p1_CardType3_Click; ///Button click event
            CardMenuVariables.p1_CardType3List.Add(p1_CardType3);
            CardMenuVariables.p1_CardType3Count++;
            CardMenuVariables.p1_yPos += 22;

            Update_Menu2();

            /// Button Location change
            foreach (Button i in CardMenuVariables.p1_CardType4List)
            {
                i.Location = new Point(386, i.Location.Y + 22);
            }
            foreach (Button i in CardMenuVariables.p1_CardType5List)
            {
                i.Location = new Point(386, i.Location.Y + 22);
            }
            foreach (Button i in CardMenuVariables.p1_CardType6List)
            {
                i.Location = new Point(386, i.Location.Y + 22);
            }
        }
        private void p1_CardType3_Click(object sender, EventArgs e)
        {
            CardMenuVariables.p1_CardType3List[CardMenuVariables.p1_CardType3Count].Dispose();
            CardMenuVariables.p1_CardType3List.RemoveAt(CardMenuVariables.p1_CardType3Count);
            CardMenuVariables.p1_CardType3Count--;
            CardMenuVariables.p1_yPos -= 22;

            Update_Menu2();

            /// Button Location change
            foreach (Button i in CardMenuVariables.p1_CardType4List)
            {
                i.Location = new Point(386, i.Location.Y - 22);
            }
            foreach (Button i in CardMenuVariables.p1_CardType5List)
            {
                i.Location = new Point(386, i.Location.Y - 22);
            }
            foreach (Button i in CardMenuVariables.p1_CardType6List)
            {
                i.Location = new Point(386, i.Location.Y - 22);
            }
        }
        #endregion
        #region Slot 4
        private void Player1_CardSlot4_click(object sender, EventArgs e)
        {
            /// Button setup            
            Button p1_CardType4 = new Button
            {
                Parent = P1Selection_Panel,
                Size = new Size(220, 23),
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.DarkGray,
                TextAlign = ContentAlignment.MiddleLeft,
                Text = Player1_CardSlot4.Text,
                FlatAppearance = { BorderSize = 0, MouseDownBackColor = Color.Transparent, MouseOverBackColor = Color.Black },
                Location = new Point(386, CardMenuVariables.p1_yPos - (CardMenuVariables.p1_CardType5Count + 1 + CardMenuVariables.p1_CardType6Count + 1) * 22)
            };

            p1_CardType4.MouseClick += p1_CardType4_Click; ///Button click event
            CardMenuVariables.p1_CardType4List.Add(p1_CardType4);
            CardMenuVariables.p1_CardType4Count++;
            CardMenuVariables.p1_yPos += 22;

            Update_Menu2();

            /// Button Location change
            foreach (Button i in CardMenuVariables.p1_CardType5List)
            {
                i.Location = new Point(386, i.Location.Y + 22);
            }
            foreach (Button i in CardMenuVariables.p1_CardType6List)
            {
                i.Location = new Point(386, i.Location.Y + 22);
            }
        }
        private void p1_CardType4_Click(object sender, EventArgs e)
        {
            CardMenuVariables.p1_CardType4List[CardMenuVariables.p1_CardType4Count].Dispose();
            CardMenuVariables.p1_CardType4List.RemoveAt(CardMenuVariables.p1_CardType4Count);
            CardMenuVariables.p1_CardType4Count--;
            CardMenuVariables.p1_yPos -= 22;

            Update_Menu2();

            /// Button Location change
            foreach (Button i in CardMenuVariables.p1_CardType5List)
            {
                i.Location = new Point(386, i.Location.Y - 22);
            }
            foreach (Button i in CardMenuVariables.p1_CardType6List)
            {
                i.Location = new Point(386, i.Location.Y - 22);
            }
        }
        #endregion
        #region Slot 5
        private void Player1_CardSlot5_click(object sender, EventArgs e)
        {
            /// Button setup            
            Button p1_CardType5 = new Button
            {
                Parent = P1Selection_Panel,
                Size = new Size(220, 23),
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.DarkGray,
                TextAlign = ContentAlignment.MiddleLeft,
                Text = Player1_CardSlot5.Text,
                FlatAppearance = { BorderSize = 0, MouseDownBackColor = Color.Transparent, MouseOverBackColor = Color.Black },
                Location = new Point(386, CardMenuVariables.p1_yPos - (CardMenuVariables.p1_CardType6Count + 1) * 22)
            };

            p1_CardType5.MouseClick += p1_CardType5_Click; ///Button click event
            CardMenuVariables.p1_CardType5List.Add(p1_CardType5);
            CardMenuVariables.p1_CardType5Count++;
            CardMenuVariables.p1_yPos += 22;

            Update_Menu2();

            /// Button Location change
            foreach (Button i in CardMenuVariables.p1_CardType6List)
            {
                i.Location = new Point(386, i.Location.Y + 22);
            }
        }
        private void p1_CardType5_Click(object sender, EventArgs e)
        {
            CardMenuVariables.p1_CardType5List[CardMenuVariables.p1_CardType5Count].Dispose();
            CardMenuVariables.p1_CardType5List.RemoveAt(CardMenuVariables.p1_CardType5Count);
            CardMenuVariables.p1_CardType5Count--;
            CardMenuVariables.p1_yPos -= 22;

            Update_Menu2();

            /// Button Location change
            foreach (Button i in CardMenuVariables.p1_CardType6List)
            {
                i.Location = new Point(386, i.Location.Y - 22);
            }
        }
        #endregion
        #region Slot 6
        private void Player1_CardSlot6_click(object sender, EventArgs e)
        {
            /// Button setup            
            Button p1_CardType6 = new Button
            {
                Parent = P1Selection_Panel,
                Size = new Size(220, 23),
                FlatStyle = FlatStyle.Flat,
                ForeColor = Color.DarkGray,
                TextAlign = ContentAlignment.MiddleLeft,
                Text = Player1_CardSlot6.Text,
                FlatAppearance = { BorderSize = 0, MouseDownBackColor = Color.Transparent, MouseOverBackColor = Color.Black },
                Location = new Point(386, CardMenuVariables.p1_yPos)
            };

            p1_CardType6.MouseClick += p1_CardType6_Click; ///Button click event
            CardMenuVariables.p1_CardType6List.Add(p1_CardType6);
            CardMenuVariables.p1_CardType6Count++;
            CardMenuVariables.p1_yPos += 22;

            Update_Menu2();

            /// Button Location change

        }
        private void p1_CardType6_Click(object sender, EventArgs e)
        {
            CardMenuVariables.p1_CardType6List[CardMenuVariables.p1_CardType6Count].Dispose();
            CardMenuVariables.p1_CardType6List.RemoveAt(CardMenuVariables.p1_CardType6Count);
            CardMenuVariables.p1_CardType6Count--;
            CardMenuVariables.p1_yPos -= 22;

            Update_Menu2();

            /// Button Location change

        }
        #endregion
        #endregion

        #region Team / Difficulty
        /// Team     
        private void Player1_Blueteam_Button_Click(object sender, EventArgs e)
        {
            /// Changes the border size of all team buttons
            Player1_Blueteam_Button.FlatAppearance.BorderSize = 1;
            Player1_Redteam_Button.FlatAppearance.BorderSize = 0;
            Player1_Greenteam_Button.FlatAppearance.BorderSize = 0;
            Player1_Yellowteam_Button.FlatAppearance.BorderSize = 0;

            Players_Manager.P1_Team = "BlueTeam";
            Update_Menu2();
        }
        private void Player1_Redteam_Button_Click(object sender, EventArgs e)
        {
            /// Changes the border size of all team buttons
            Player1_Blueteam_Button.FlatAppearance.BorderSize = 0;
            Player1_Redteam_Button.FlatAppearance.BorderSize = 1;
            Player1_Greenteam_Button.FlatAppearance.BorderSize = 0;
            Player1_Yellowteam_Button.FlatAppearance.BorderSize = 0;

            Players_Manager.P1_Team = "RedTeam";
            Update_Menu2();
        }
        private void Player1_Greenteam_Button_Click(object sender, EventArgs e)
        {
            /// Changes the border size of all team buttons
            Player1_Blueteam_Button.FlatAppearance.BorderSize = 0;
            Player1_Redteam_Button.FlatAppearance.BorderSize = 0;
            Player1_Greenteam_Button.FlatAppearance.BorderSize = 1;
            Player1_Yellowteam_Button.FlatAppearance.BorderSize = 0;

            Players_Manager.P1_Team = "GreenTeam";
            Update_Menu2();
        }
        private void Player1_Yellowteam_Button_Click(object sender, EventArgs e)
        {
            /// Changes the border size of all team buttons
            Player1_Blueteam_Button.FlatAppearance.BorderSize = 0;
            Player1_Redteam_Button.FlatAppearance.BorderSize = 0;
            Player1_Greenteam_Button.FlatAppearance.BorderSize = 0;
            Player1_Yellowteam_Button.FlatAppearance.BorderSize = 1;

            Players_Manager.P1_Team = "YellowTeam";
            Update_Menu2();
        }

        /// Difficulty
        private void Easy_Button_Click(object sender, EventArgs e)
        {
            Easy_Button.FlatAppearance.BorderSize = 1;
            Normal_Button.FlatAppearance.BorderSize = 0;
            Hard_Button.FlatAppearance.BorderSize = 0;

            Setting_Manager.difficulty = "Easy";

            Update_Menu2();
        }
        private void Normal_Button_Click(object sender, EventArgs e)
        {
            Easy_Button.FlatAppearance.BorderSize = 0;
            Normal_Button.FlatAppearance.BorderSize = 1;
            Hard_Button.FlatAppearance.BorderSize = 0;

            Setting_Manager.difficulty = "Normal";

            Update_Menu2();
        }
        private void Hard_Button_Click(object sender, EventArgs e)
        {
            Easy_Button.FlatAppearance.BorderSize = 0;
            Normal_Button.FlatAppearance.BorderSize = 0;
            Hard_Button.FlatAppearance.BorderSize = 1;

            Setting_Manager.difficulty = "Hard";

            Update_Menu2();
        }

        #endregion


        #endregion

        private void Boardgame_Scroll(object sender, ScrollEventArgs e)
        {
            if (e.OldValue > e.NewValue)
            {
                // here up

            }
            else
            {
                // here down
            }
        }

        
    }
}
