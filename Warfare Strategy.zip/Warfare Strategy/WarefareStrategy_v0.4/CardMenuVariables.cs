﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WarefareStrategy_v0._4
{
    class CardMenuVariables
    {
        #region Card Selection Variables
        public static int p1_yPos = 23; ///this variable is used for setting the y position of the buttons that are added into the 'cards selected' menu
        public static int p1_CardType1Count = -1; // Makes into p1_Cardtype bla bla bla for everything
        public static int p1_CardType2Count = -1;
        public static int p1_CardType3Count = -1;
        public static int p1_CardType4Count = -1;
        public static int p1_CardType5Count = -1;
        public static int p1_CardType6Count = -1;
        public static List<Button> p1_CardType1List = new List<Button>();
        public static List<Button> p1_CardType2List = new List<Button>();
        public static List<Button> p1_CardType3List = new List<Button>();
        public static List<Button> p1_CardType4List = new List<Button>();
        public static List<Button> p1_CardType5List = new List<Button>();
        public static List<Button> p1_CardType6List = new List<Button>();
        public static List<Button> p1_AllCardTypesList = new List<Button>();
        #endregion

        #region Side Statistics Variables
        public static int p1_CardCount = 0; ///the number of cards a player has in their deck
        public static int p1_MeleeCardCount = 0; ///the number of melee cards in a players deck
        public static int p1_RangeCardCount = 0; ///the number of range cards in a players deck
        public static int p1_SpecialCardCount = 0; ///the number of special cards in a players deck
        #endregion

    }
}
