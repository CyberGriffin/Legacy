﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WarefareStrategy_v0._4
{
    class Players_Manager
    {
        public static string P1_Team = "BlueTeam";
        public static string P2_Team = "RedTeam";
    }
}
