﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WarefareStrategy_v0._4
{
    class Addon_Manager
    {
        #region Variables
        public static bool addons_Timer_Active = false;
        public static bool addons_Master_Active = false;
        public static bool addons_Random_Active = false;
        public static int addons_ActiveCount = 0;
        #endregion
    }
}
