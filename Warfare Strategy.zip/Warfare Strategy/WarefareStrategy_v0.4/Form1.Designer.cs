﻿namespace WarefareStrategy_v0._4
{
    partial class Boardgame
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Boardgame));
            this.sett_Popup_Label = new System.Windows.Forms.Label();
            this.Menu3 = new System.Windows.Forms.Panel();
            this.sett_Back_Button = new System.Windows.Forms.Button();
            this.sett_GameSpeed_Button = new System.Windows.Forms.Button();
            this.sett_Console_Button = new System.Windows.Forms.Button();
            this.sett_Sound_Button = new System.Windows.Forms.Button();
            this.OpponentHand_Panel = new System.Windows.Forms.Panel();
            this.OpponentHand5_PictureBox = new System.Windows.Forms.PictureBox();
            this.OpponentHand4_PictureBox = new System.Windows.Forms.PictureBox();
            this.OpponentHand2_PictureBox = new System.Windows.Forms.PictureBox();
            this.OpponentHand3_PictureBox = new System.Windows.Forms.PictureBox();
            this.OpponentHand1_PictureBox = new System.Windows.Forms.PictureBox();
            this.PlayerHand_Panel = new System.Windows.Forms.Panel();
            this.PlayerHand5_PictureBox = new System.Windows.Forms.PictureBox();
            this.PlayerHand4_PictureBox = new System.Windows.Forms.PictureBox();
            this.PlayerHand2_PictureBox = new System.Windows.Forms.PictureBox();
            this.PlayerHand3_PictureBox = new System.Windows.Forms.PictureBox();
            this.PlayerHand1_PictureBox = new System.Windows.Forms.PictureBox();
            this.OpponentDeck_PictureBox = new System.Windows.Forms.PictureBox();
            this.PlayerDeck_PictureBox = new System.Windows.Forms.PictureBox();
            this.Menu2 = new System.Windows.Forms.Panel();
            this.add_Back_Button = new System.Windows.Forms.Button();
            this.add_Random_Button = new System.Windows.Forms.Button();
            this.add_Master_Button = new System.Windows.Forms.Button();
            this.add_Timer_Button = new System.Windows.Forms.Button();
            this.Menu1 = new System.Windows.Forms.Panel();
            this.Setting_Button = new System.Windows.Forms.Button();
            this.Exit_Button = new System.Windows.Forms.Button();
            this.Addon_Button = new System.Windows.Forms.Button();
            this.Play_Button = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.sett_Popup_Timer = new System.Windows.Forms.Timer(this.components);
            this.P1Selection_Panel = new System.Windows.Forms.Panel();
            this.Player1_CardSlot6 = new System.Windows.Forms.Button();
            this.Player1_CardSlot5 = new System.Windows.Forms.Button();
            this.Player1_CardSlot4 = new System.Windows.Forms.Button();
            this.Player1_CardSlot3 = new System.Windows.Forms.Button();
            this.Player1_CardSlot2 = new System.Windows.Forms.Button();
            this.Player1_CardSlot1 = new System.Windows.Forms.Button();
            this.p1_GameSpeed_Label = new System.Windows.Forms.Label();
            this.p1_Console_Label = new System.Windows.Forms.Label();
            this.p1_Sound_Label = new System.Windows.Forms.Label();
            this.p1_Settings_Label = new System.Windows.Forms.Label();
            this.p1_Random_Label = new System.Windows.Forms.Label();
            this.p1_Master_Label = new System.Windows.Forms.Label();
            this.p1_Timer_Label = new System.Windows.Forms.Label();
            this.p1_Addons_Label = new System.Windows.Forms.Label();
            this.p1_Team_Label = new System.Windows.Forms.Label();
            this.p1_Skill_Label = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.playerGold_Label = new System.Windows.Forms.Label();
            this.p1_Difficulty_Label = new System.Windows.Forms.Label();
            this.p1_Guard_Label = new System.Windows.Forms.Label();
            this.p1_General_Label = new System.Windows.Forms.Label();
            this.p1_Special_Label = new System.Windows.Forms.Label();
            this.p1_Range_Label = new System.Windows.Forms.Label();
            this.p1_Melee_Label = new System.Windows.Forms.Label();
            this.p1_Units_Label = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.Player1_Blueteam_Button = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Player1_Redteam_Button = new System.Windows.Forms.Button();
            this.Player1_Greenteam_Button = new System.Windows.Forms.Button();
            this.Player1_Yellowteam_Button = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.Easy_Button = new System.Windows.Forms.Button();
            this.Normal_Button = new System.Windows.Forms.Button();
            this.Hard_Button = new System.Windows.Forms.Button();
            this.Menu3.SuspendLayout();
            this.OpponentHand_Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentHand5_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentHand4_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentHand2_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentHand3_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentHand1_PictureBox)).BeginInit();
            this.PlayerHand_Panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHand5_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHand4_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHand2_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHand3_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHand1_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentDeck_PictureBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerDeck_PictureBox)).BeginInit();
            this.Menu2.SuspendLayout();
            this.Menu1.SuspendLayout();
            this.P1Selection_Panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // sett_Popup_Label
            // 
            this.sett_Popup_Label.BackColor = System.Drawing.Color.Transparent;
            this.sett_Popup_Label.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.sett_Popup_Label.Location = new System.Drawing.Point(688, 529);
            this.sett_Popup_Label.Name = "sett_Popup_Label";
            this.sett_Popup_Label.Size = new System.Drawing.Size(153, 102);
            this.sett_Popup_Label.TabIndex = 26;
            this.sett_Popup_Label.Text = "1 - slow,  2 - normal,  3 - fast";
            this.sett_Popup_Label.Visible = false;
            // 
            // Menu3
            // 
            this.Menu3.BackColor = System.Drawing.Color.Transparent;
            this.Menu3.Controls.Add(this.sett_Back_Button);
            this.Menu3.Controls.Add(this.sett_GameSpeed_Button);
            this.Menu3.Controls.Add(this.sett_Console_Button);
            this.Menu3.Controls.Add(this.sett_Sound_Button);
            this.Menu3.Location = new System.Drawing.Point(590, 451);
            this.Menu3.Name = "Menu3";
            this.Menu3.Size = new System.Drawing.Size(90, 133);
            this.Menu3.TabIndex = 25;
            this.Menu3.Visible = false;
            // 
            // sett_Back_Button
            // 
            this.sett_Back_Button.BackColor = System.Drawing.Color.DarkGray;
            this.sett_Back_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sett_Back_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.sett_Back_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sett_Back_Button.Location = new System.Drawing.Point(5, 105);
            this.sett_Back_Button.Name = "sett_Back_Button";
            this.sett_Back_Button.Size = new System.Drawing.Size(80, 28);
            this.sett_Back_Button.TabIndex = 13;
            this.sett_Back_Button.TabStop = false;
            this.sett_Back_Button.Text = "Back";
            this.sett_Back_Button.UseVisualStyleBackColor = false;
            this.sett_Back_Button.Click += new System.EventHandler(this.sett_Back_Button_Click);
            // 
            // sett_GameSpeed_Button
            // 
            this.sett_GameSpeed_Button.BackColor = System.Drawing.Color.DarkGray;
            this.sett_GameSpeed_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sett_GameSpeed_Button.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.sett_GameSpeed_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.sett_GameSpeed_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sett_GameSpeed_Button.Font = new System.Drawing.Font("Times New Roman", 8.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.sett_GameSpeed_Button.Location = new System.Drawing.Point(-2, 71);
            this.sett_GameSpeed_Button.Name = "sett_GameSpeed_Button";
            this.sett_GameSpeed_Button.Size = new System.Drawing.Size(94, 28);
            this.sett_GameSpeed_Button.TabIndex = 12;
            this.sett_GameSpeed_Button.TabStop = false;
            this.sett_GameSpeed_Button.Text = "Game-Speed - 2";
            this.sett_GameSpeed_Button.UseVisualStyleBackColor = false;
            this.sett_GameSpeed_Button.Click += new System.EventHandler(this.sett_GameSpeed_Button_Click);
            this.sett_GameSpeed_Button.MouseLeave += new System.EventHandler(this.sett_GameSpeed_Button_MouseLeave);
            this.sett_GameSpeed_Button.MouseHover += new System.EventHandler(this.sett_GameSpeed_Button_MouseHover);
            // 
            // sett_Console_Button
            // 
            this.sett_Console_Button.BackColor = System.Drawing.Color.DarkGray;
            this.sett_Console_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sett_Console_Button.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.sett_Console_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.sett_Console_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sett_Console_Button.Location = new System.Drawing.Point(-2, 35);
            this.sett_Console_Button.Name = "sett_Console_Button";
            this.sett_Console_Button.Size = new System.Drawing.Size(94, 28);
            this.sett_Console_Button.TabIndex = 11;
            this.sett_Console_Button.TabStop = false;
            this.sett_Console_Button.Text = "Console - off";
            this.sett_Console_Button.UseVisualStyleBackColor = false;
            this.sett_Console_Button.Click += new System.EventHandler(this.sett_Console_Button_Click);
            // 
            // sett_Sound_Button
            // 
            this.sett_Sound_Button.BackColor = System.Drawing.Color.DarkGray;
            this.sett_Sound_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.sett_Sound_Button.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.sett_Sound_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.sett_Sound_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.sett_Sound_Button.Location = new System.Drawing.Point(-2, 0);
            this.sett_Sound_Button.Name = "sett_Sound_Button";
            this.sett_Sound_Button.Size = new System.Drawing.Size(94, 28);
            this.sett_Sound_Button.TabIndex = 10;
            this.sett_Sound_Button.TabStop = false;
            this.sett_Sound_Button.Text = "Sound - on";
            this.sett_Sound_Button.UseVisualStyleBackColor = false;
            this.sett_Sound_Button.Click += new System.EventHandler(this.sett_Sound_Button_Click);
            // 
            // OpponentHand_Panel
            // 
            this.OpponentHand_Panel.BackColor = System.Drawing.Color.Transparent;
            this.OpponentHand_Panel.Controls.Add(this.OpponentHand5_PictureBox);
            this.OpponentHand_Panel.Controls.Add(this.OpponentHand4_PictureBox);
            this.OpponentHand_Panel.Controls.Add(this.OpponentHand2_PictureBox);
            this.OpponentHand_Panel.Controls.Add(this.OpponentHand3_PictureBox);
            this.OpponentHand_Panel.Controls.Add(this.OpponentHand1_PictureBox);
            this.OpponentHand_Panel.Location = new System.Drawing.Point(455, 8);
            this.OpponentHand_Panel.Name = "OpponentHand_Panel";
            this.OpponentHand_Panel.Size = new System.Drawing.Size(462, 142);
            this.OpponentHand_Panel.TabIndex = 24;
            // 
            // OpponentHand5_PictureBox
            // 
            this.OpponentHand5_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.OpponentHand5_PictureBox.Location = new System.Drawing.Point(380, 0);
            this.OpponentHand5_PictureBox.Name = "OpponentHand5_PictureBox";
            this.OpponentHand5_PictureBox.Size = new System.Drawing.Size(82, 142);
            this.OpponentHand5_PictureBox.TabIndex = 4;
            this.OpponentHand5_PictureBox.TabStop = false;
            // 
            // OpponentHand4_PictureBox
            // 
            this.OpponentHand4_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.OpponentHand4_PictureBox.Location = new System.Drawing.Point(285, 0);
            this.OpponentHand4_PictureBox.Name = "OpponentHand4_PictureBox";
            this.OpponentHand4_PictureBox.Size = new System.Drawing.Size(82, 142);
            this.OpponentHand4_PictureBox.TabIndex = 3;
            this.OpponentHand4_PictureBox.TabStop = false;
            // 
            // OpponentHand2_PictureBox
            // 
            this.OpponentHand2_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.OpponentHand2_PictureBox.Location = new System.Drawing.Point(95, 0);
            this.OpponentHand2_PictureBox.Name = "OpponentHand2_PictureBox";
            this.OpponentHand2_PictureBox.Size = new System.Drawing.Size(82, 142);
            this.OpponentHand2_PictureBox.TabIndex = 2;
            this.OpponentHand2_PictureBox.TabStop = false;
            // 
            // OpponentHand3_PictureBox
            // 
            this.OpponentHand3_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.OpponentHand3_PictureBox.Location = new System.Drawing.Point(190, 0);
            this.OpponentHand3_PictureBox.Name = "OpponentHand3_PictureBox";
            this.OpponentHand3_PictureBox.Size = new System.Drawing.Size(82, 142);
            this.OpponentHand3_PictureBox.TabIndex = 1;
            this.OpponentHand3_PictureBox.TabStop = false;
            // 
            // OpponentHand1_PictureBox
            // 
            this.OpponentHand1_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.OpponentHand1_PictureBox.Location = new System.Drawing.Point(0, 0);
            this.OpponentHand1_PictureBox.Name = "OpponentHand1_PictureBox";
            this.OpponentHand1_PictureBox.Size = new System.Drawing.Size(82, 142);
            this.OpponentHand1_PictureBox.TabIndex = 0;
            this.OpponentHand1_PictureBox.TabStop = false;
            // 
            // PlayerHand_Panel
            // 
            this.PlayerHand_Panel.BackColor = System.Drawing.Color.Transparent;
            this.PlayerHand_Panel.Controls.Add(this.PlayerHand5_PictureBox);
            this.PlayerHand_Panel.Controls.Add(this.PlayerHand4_PictureBox);
            this.PlayerHand_Panel.Controls.Add(this.PlayerHand2_PictureBox);
            this.PlayerHand_Panel.Controls.Add(this.PlayerHand3_PictureBox);
            this.PlayerHand_Panel.Controls.Add(this.PlayerHand1_PictureBox);
            this.PlayerHand_Panel.Cursor = System.Windows.Forms.Cursors.Default;
            this.PlayerHand_Panel.Location = new System.Drawing.Point(450, 677);
            this.PlayerHand_Panel.Name = "PlayerHand_Panel";
            this.PlayerHand_Panel.Size = new System.Drawing.Size(472, 152);
            this.PlayerHand_Panel.TabIndex = 23;
            this.PlayerHand_Panel.Visible = false;
            // 
            // PlayerHand5_PictureBox
            // 
            this.PlayerHand5_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.PlayerHand5_PictureBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PlayerHand5_PictureBox.Enabled = false;
            this.PlayerHand5_PictureBox.Location = new System.Drawing.Point(385, 5);
            this.PlayerHand5_PictureBox.Name = "PlayerHand5_PictureBox";
            this.PlayerHand5_PictureBox.Size = new System.Drawing.Size(82, 142);
            this.PlayerHand5_PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PlayerHand5_PictureBox.TabIndex = 4;
            this.PlayerHand5_PictureBox.TabStop = false;
            // 
            // PlayerHand4_PictureBox
            // 
            this.PlayerHand4_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.PlayerHand4_PictureBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PlayerHand4_PictureBox.Enabled = false;
            this.PlayerHand4_PictureBox.Location = new System.Drawing.Point(290, 5);
            this.PlayerHand4_PictureBox.Name = "PlayerHand4_PictureBox";
            this.PlayerHand4_PictureBox.Size = new System.Drawing.Size(82, 142);
            this.PlayerHand4_PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PlayerHand4_PictureBox.TabIndex = 3;
            this.PlayerHand4_PictureBox.TabStop = false;
            // 
            // PlayerHand2_PictureBox
            // 
            this.PlayerHand2_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.PlayerHand2_PictureBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PlayerHand2_PictureBox.Enabled = false;
            this.PlayerHand2_PictureBox.Location = new System.Drawing.Point(100, 5);
            this.PlayerHand2_PictureBox.Name = "PlayerHand2_PictureBox";
            this.PlayerHand2_PictureBox.Size = new System.Drawing.Size(82, 142);
            this.PlayerHand2_PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PlayerHand2_PictureBox.TabIndex = 2;
            this.PlayerHand2_PictureBox.TabStop = false;
            // 
            // PlayerHand3_PictureBox
            // 
            this.PlayerHand3_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.PlayerHand3_PictureBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PlayerHand3_PictureBox.Enabled = false;
            this.PlayerHand3_PictureBox.Location = new System.Drawing.Point(195, 5);
            this.PlayerHand3_PictureBox.Name = "PlayerHand3_PictureBox";
            this.PlayerHand3_PictureBox.Size = new System.Drawing.Size(82, 142);
            this.PlayerHand3_PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PlayerHand3_PictureBox.TabIndex = 1;
            this.PlayerHand3_PictureBox.TabStop = false;
            // 
            // PlayerHand1_PictureBox
            // 
            this.PlayerHand1_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.PlayerHand1_PictureBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PlayerHand1_PictureBox.Enabled = false;
            this.PlayerHand1_PictureBox.Location = new System.Drawing.Point(5, 5);
            this.PlayerHand1_PictureBox.Name = "PlayerHand1_PictureBox";
            this.PlayerHand1_PictureBox.Size = new System.Drawing.Size(82, 142);
            this.PlayerHand1_PictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.PlayerHand1_PictureBox.TabIndex = 0;
            this.PlayerHand1_PictureBox.TabStop = false;
            // 
            // OpponentDeck_PictureBox
            // 
            this.OpponentDeck_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.OpponentDeck_PictureBox.Location = new System.Drawing.Point(244, 2);
            this.OpponentDeck_PictureBox.Name = "OpponentDeck_PictureBox";
            this.OpponentDeck_PictureBox.Size = new System.Drawing.Size(86, 148);
            this.OpponentDeck_PictureBox.TabIndex = 22;
            this.OpponentDeck_PictureBox.TabStop = false;
            // 
            // PlayerDeck_PictureBox
            // 
            this.PlayerDeck_PictureBox.BackColor = System.Drawing.Color.Transparent;
            this.PlayerDeck_PictureBox.Cursor = System.Windows.Forms.Cursors.Hand;
            this.PlayerDeck_PictureBox.Enabled = false;
            this.PlayerDeck_PictureBox.Location = new System.Drawing.Point(244, 676);
            this.PlayerDeck_PictureBox.Name = "PlayerDeck_PictureBox";
            this.PlayerDeck_PictureBox.Size = new System.Drawing.Size(86, 148);
            this.PlayerDeck_PictureBox.TabIndex = 21;
            this.PlayerDeck_PictureBox.TabStop = false;
            // 
            // Menu2
            // 
            this.Menu2.BackColor = System.Drawing.Color.Transparent;
            this.Menu2.Controls.Add(this.add_Back_Button);
            this.Menu2.Controls.Add(this.add_Random_Button);
            this.Menu2.Controls.Add(this.add_Master_Button);
            this.Menu2.Controls.Add(this.add_Timer_Button);
            this.Menu2.Cursor = System.Windows.Forms.Cursors.Default;
            this.Menu2.Location = new System.Drawing.Point(590, 451);
            this.Menu2.Name = "Menu2";
            this.Menu2.Size = new System.Drawing.Size(90, 133);
            this.Menu2.TabIndex = 20;
            this.Menu2.Visible = false;
            // 
            // add_Back_Button
            // 
            this.add_Back_Button.BackColor = System.Drawing.Color.DarkGray;
            this.add_Back_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.add_Back_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.add_Back_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.add_Back_Button.Location = new System.Drawing.Point(5, 105);
            this.add_Back_Button.Name = "add_Back_Button";
            this.add_Back_Button.Size = new System.Drawing.Size(80, 28);
            this.add_Back_Button.TabIndex = 12;
            this.add_Back_Button.TabStop = false;
            this.add_Back_Button.Text = "Back";
            this.add_Back_Button.UseVisualStyleBackColor = false;
            this.add_Back_Button.Click += new System.EventHandler(this.add_Back_Button_Click);
            // 
            // add_Random_Button
            // 
            this.add_Random_Button.BackColor = System.Drawing.Color.DarkGray;
            this.add_Random_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.add_Random_Button.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.add_Random_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.add_Random_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.add_Random_Button.Location = new System.Drawing.Point(-2, 71);
            this.add_Random_Button.Name = "add_Random_Button";
            this.add_Random_Button.Size = new System.Drawing.Size(94, 28);
            this.add_Random_Button.TabIndex = 11;
            this.add_Random_Button.TabStop = false;
            this.add_Random_Button.Text = "Random Deck";
            this.add_Random_Button.UseVisualStyleBackColor = false;
            this.add_Random_Button.Click += new System.EventHandler(this.add_Random_Button_Click);
            // 
            // add_Master_Button
            // 
            this.add_Master_Button.BackColor = System.Drawing.Color.DarkGray;
            this.add_Master_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.add_Master_Button.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.add_Master_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.add_Master_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.add_Master_Button.Location = new System.Drawing.Point(-2, 35);
            this.add_Master_Button.Name = "add_Master_Button";
            this.add_Master_Button.Size = new System.Drawing.Size(94, 28);
            this.add_Master_Button.TabIndex = 10;
            this.add_Master_Button.TabStop = false;
            this.add_Master_Button.Text = "Master Mode";
            this.add_Master_Button.UseVisualStyleBackColor = false;
            this.add_Master_Button.Click += new System.EventHandler(this.add_Master_Button_Click);
            // 
            // add_Timer_Button
            // 
            this.add_Timer_Button.BackColor = System.Drawing.Color.DarkGray;
            this.add_Timer_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.add_Timer_Button.FlatAppearance.BorderColor = System.Drawing.Color.Black;
            this.add_Timer_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.add_Timer_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.add_Timer_Button.Location = new System.Drawing.Point(-2, 0);
            this.add_Timer_Button.Name = "add_Timer_Button";
            this.add_Timer_Button.Size = new System.Drawing.Size(94, 28);
            this.add_Timer_Button.TabIndex = 9;
            this.add_Timer_Button.TabStop = false;
            this.add_Timer_Button.Text = "In-Game Timer";
            this.add_Timer_Button.UseVisualStyleBackColor = false;
            this.add_Timer_Button.Click += new System.EventHandler(this.add_Timer_Button_Click);
            // 
            // Menu1
            // 
            this.Menu1.BackColor = System.Drawing.Color.Transparent;
            this.Menu1.Controls.Add(this.Setting_Button);
            this.Menu1.Controls.Add(this.Exit_Button);
            this.Menu1.Controls.Add(this.Addon_Button);
            this.Menu1.Controls.Add(this.Play_Button);
            this.Menu1.Location = new System.Drawing.Point(590, 451);
            this.Menu1.Name = "Menu1";
            this.Menu1.Size = new System.Drawing.Size(90, 133);
            this.Menu1.TabIndex = 19;
            // 
            // Setting_Button
            // 
            this.Setting_Button.BackColor = System.Drawing.Color.DarkGray;
            this.Setting_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Setting_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.Setting_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Setting_Button.Location = new System.Drawing.Point(0, 71);
            this.Setting_Button.Name = "Setting_Button";
            this.Setting_Button.Size = new System.Drawing.Size(90, 28);
            this.Setting_Button.TabIndex = 7;
            this.Setting_Button.TabStop = false;
            this.Setting_Button.Text = "Settings";
            this.Setting_Button.UseVisualStyleBackColor = false;
            this.Setting_Button.Click += new System.EventHandler(this.Setting_Button_Click);
            // 
            // Exit_Button
            // 
            this.Exit_Button.BackColor = System.Drawing.Color.DarkGray;
            this.Exit_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Exit_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.Exit_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Exit_Button.Location = new System.Drawing.Point(0, 105);
            this.Exit_Button.Name = "Exit_Button";
            this.Exit_Button.Size = new System.Drawing.Size(90, 28);
            this.Exit_Button.TabIndex = 6;
            this.Exit_Button.TabStop = false;
            this.Exit_Button.Text = "Exit";
            this.Exit_Button.UseVisualStyleBackColor = false;
            this.Exit_Button.Click += new System.EventHandler(this.Exit_Button_Click);
            // 
            // Addon_Button
            // 
            this.Addon_Button.BackColor = System.Drawing.Color.DarkGray;
            this.Addon_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Addon_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.Addon_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Addon_Button.Location = new System.Drawing.Point(0, 35);
            this.Addon_Button.Name = "Addon_Button";
            this.Addon_Button.Size = new System.Drawing.Size(90, 28);
            this.Addon_Button.TabIndex = 5;
            this.Addon_Button.TabStop = false;
            this.Addon_Button.Text = "Addons";
            this.Addon_Button.UseVisualStyleBackColor = false;
            this.Addon_Button.Click += new System.EventHandler(this.Addon_Button_Click);
            // 
            // Play_Button
            // 
            this.Play_Button.BackColor = System.Drawing.Color.DarkGray;
            this.Play_Button.Cursor = System.Windows.Forms.Cursors.Hand;
            this.Play_Button.FlatAppearance.MouseOverBackColor = System.Drawing.Color.DarkGray;
            this.Play_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Play_Button.Location = new System.Drawing.Point(0, 0);
            this.Play_Button.Name = "Play_Button";
            this.Play_Button.Size = new System.Drawing.Size(90, 28);
            this.Play_Button.TabIndex = 4;
            this.Play_Button.TabStop = false;
            this.Play_Button.Text = "Play Game";
            this.Play_Button.UseVisualStyleBackColor = false;
            this.Play_Button.Click += new System.EventHandler(this.Play_Button_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.label1.Location = new System.Drawing.Point(1231, 808);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 15);
            this.label1.TabIndex = 18;
            this.label1.Text = "v0.4";
            // 
            // sett_Popup_Timer
            // 
            this.sett_Popup_Timer.Interval = 1000;
            this.sett_Popup_Timer.Tick += new System.EventHandler(this.sett_Popup_Timer_Tick);
            // 
            // P1Selection_Panel
            // 
            this.P1Selection_Panel.BackColor = System.Drawing.Color.Transparent;
            this.P1Selection_Panel.Controls.Add(this.Hard_Button);
            this.P1Selection_Panel.Controls.Add(this.Normal_Button);
            this.P1Selection_Panel.Controls.Add(this.Easy_Button);
            this.P1Selection_Panel.Controls.Add(this.label3);
            this.P1Selection_Panel.Controls.Add(this.Player1_Yellowteam_Button);
            this.P1Selection_Panel.Controls.Add(this.Player1_Greenteam_Button);
            this.P1Selection_Panel.Controls.Add(this.Player1_Redteam_Button);
            this.P1Selection_Panel.Controls.Add(this.label2);
            this.P1Selection_Panel.Controls.Add(this.Player1_Blueteam_Button);
            this.P1Selection_Panel.Controls.Add(this.Player1_CardSlot6);
            this.P1Selection_Panel.Controls.Add(this.Player1_CardSlot5);
            this.P1Selection_Panel.Controls.Add(this.Player1_CardSlot4);
            this.P1Selection_Panel.Controls.Add(this.Player1_CardSlot3);
            this.P1Selection_Panel.Controls.Add(this.Player1_CardSlot2);
            this.P1Selection_Panel.Controls.Add(this.Player1_CardSlot1);
            this.P1Selection_Panel.Controls.Add(this.p1_GameSpeed_Label);
            this.P1Selection_Panel.Controls.Add(this.p1_Console_Label);
            this.P1Selection_Panel.Controls.Add(this.p1_Sound_Label);
            this.P1Selection_Panel.Controls.Add(this.p1_Settings_Label);
            this.P1Selection_Panel.Controls.Add(this.p1_Random_Label);
            this.P1Selection_Panel.Controls.Add(this.p1_Master_Label);
            this.P1Selection_Panel.Controls.Add(this.p1_Timer_Label);
            this.P1Selection_Panel.Controls.Add(this.p1_Addons_Label);
            this.P1Selection_Panel.Controls.Add(this.p1_Team_Label);
            this.P1Selection_Panel.Controls.Add(this.p1_Skill_Label);
            this.P1Selection_Panel.Controls.Add(this.button3);
            this.P1Selection_Panel.Controls.Add(this.playerGold_Label);
            this.P1Selection_Panel.Controls.Add(this.p1_Difficulty_Label);
            this.P1Selection_Panel.Controls.Add(this.p1_Guard_Label);
            this.P1Selection_Panel.Controls.Add(this.p1_General_Label);
            this.P1Selection_Panel.Controls.Add(this.p1_Special_Label);
            this.P1Selection_Panel.Controls.Add(this.p1_Range_Label);
            this.P1Selection_Panel.Controls.Add(this.p1_Melee_Label);
            this.P1Selection_Panel.Controls.Add(this.p1_Units_Label);
            this.P1Selection_Panel.Controls.Add(this.button2);
            this.P1Selection_Panel.Controls.Add(this.button1);
            this.P1Selection_Panel.Location = new System.Drawing.Point(266, 236);
            this.P1Selection_Panel.Name = "P1Selection_Panel";
            this.P1Selection_Panel.Size = new System.Drawing.Size(738, 360);
            this.P1Selection_Panel.TabIndex = 27;
            this.P1Selection_Panel.Visible = false;
            // 
            // Player1_CardSlot6
            // 
            this.Player1_CardSlot6.FlatAppearance.BorderSize = 0;
            this.Player1_CardSlot6.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.Player1_CardSlot6.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Player1_CardSlot6.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Player1_CardSlot6.ForeColor = System.Drawing.Color.DarkGray;
            this.Player1_CardSlot6.Location = new System.Drawing.Point(132, 133);
            this.Player1_CardSlot6.Name = "Player1_CardSlot6";
            this.Player1_CardSlot6.Size = new System.Drawing.Size(220, 23);
            this.Player1_CardSlot6.TabIndex = 26;
            this.Player1_CardSlot6.Text = "General  |  200 gold";
            this.Player1_CardSlot6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Player1_CardSlot6.UseVisualStyleBackColor = true;
            this.Player1_CardSlot6.Click += new System.EventHandler(this.Player1_CardSlot6_click);
            // 
            // Player1_CardSlot5
            // 
            this.Player1_CardSlot5.FlatAppearance.BorderSize = 0;
            this.Player1_CardSlot5.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.Player1_CardSlot5.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Player1_CardSlot5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Player1_CardSlot5.ForeColor = System.Drawing.Color.DarkGray;
            this.Player1_CardSlot5.Location = new System.Drawing.Point(132, 111);
            this.Player1_CardSlot5.Name = "Player1_CardSlot5";
            this.Player1_CardSlot5.Size = new System.Drawing.Size(220, 23);
            this.Player1_CardSlot5.TabIndex = 25;
            this.Player1_CardSlot5.Text = "Crossbowmen  |  80 gold";
            this.Player1_CardSlot5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Player1_CardSlot5.UseVisualStyleBackColor = true;
            this.Player1_CardSlot5.Click += new System.EventHandler(this.Player1_CardSlot5_click);
            // 
            // Player1_CardSlot4
            // 
            this.Player1_CardSlot4.FlatAppearance.BorderSize = 0;
            this.Player1_CardSlot4.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.Player1_CardSlot4.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Player1_CardSlot4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Player1_CardSlot4.ForeColor = System.Drawing.Color.DarkGray;
            this.Player1_CardSlot4.Location = new System.Drawing.Point(132, 89);
            this.Player1_CardSlot4.Name = "Player1_CardSlot4";
            this.Player1_CardSlot4.Size = new System.Drawing.Size(220, 23);
            this.Player1_CardSlot4.TabIndex = 24;
            this.Player1_CardSlot4.Text = "Archers  |  60 gold";
            this.Player1_CardSlot4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Player1_CardSlot4.UseVisualStyleBackColor = true;
            this.Player1_CardSlot4.Click += new System.EventHandler(this.Player1_CardSlot4_click);
            // 
            // Player1_CardSlot3
            // 
            this.Player1_CardSlot3.FlatAppearance.BorderSize = 0;
            this.Player1_CardSlot3.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.Player1_CardSlot3.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Player1_CardSlot3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Player1_CardSlot3.ForeColor = System.Drawing.Color.DarkGray;
            this.Player1_CardSlot3.Location = new System.Drawing.Point(132, 67);
            this.Player1_CardSlot3.Name = "Player1_CardSlot3";
            this.Player1_CardSlot3.Size = new System.Drawing.Size(220, 23);
            this.Player1_CardSlot3.TabIndex = 23;
            this.Player1_CardSlot3.Text = "Axemen  |  70 gold";
            this.Player1_CardSlot3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Player1_CardSlot3.UseVisualStyleBackColor = true;
            this.Player1_CardSlot3.Click += new System.EventHandler(this.Player1_CardSlot3_click);
            // 
            // Player1_CardSlot2
            // 
            this.Player1_CardSlot2.FlatAppearance.BorderSize = 0;
            this.Player1_CardSlot2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.Player1_CardSlot2.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Player1_CardSlot2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Player1_CardSlot2.ForeColor = System.Drawing.Color.DarkGray;
            this.Player1_CardSlot2.Location = new System.Drawing.Point(132, 45);
            this.Player1_CardSlot2.Name = "Player1_CardSlot2";
            this.Player1_CardSlot2.Size = new System.Drawing.Size(220, 23);
            this.Player1_CardSlot2.TabIndex = 22;
            this.Player1_CardSlot2.Text = "Swordsmen  |  50 gold";
            this.Player1_CardSlot2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Player1_CardSlot2.UseVisualStyleBackColor = true;
            this.Player1_CardSlot2.Click += new System.EventHandler(this.Player1_CardSlot2_Click);
            // 
            // Player1_CardSlot1
            // 
            this.Player1_CardSlot1.FlatAppearance.BorderSize = 0;
            this.Player1_CardSlot1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.Player1_CardSlot1.FlatAppearance.MouseOverBackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Player1_CardSlot1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Player1_CardSlot1.ForeColor = System.Drawing.Color.DarkGray;
            this.Player1_CardSlot1.Location = new System.Drawing.Point(132, 23);
            this.Player1_CardSlot1.Name = "Player1_CardSlot1";
            this.Player1_CardSlot1.Size = new System.Drawing.Size(220, 23);
            this.Player1_CardSlot1.TabIndex = 21;
            this.Player1_CardSlot1.Tag = "";
            this.Player1_CardSlot1.Text = "Spearmen  |  50 gold";
            this.Player1_CardSlot1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Player1_CardSlot1.UseVisualStyleBackColor = true;
            this.Player1_CardSlot1.Click += new System.EventHandler(this.Player1_CardSlot1_click);
            // 
            // p1_GameSpeed_Label
            // 
            this.p1_GameSpeed_Label.AutoSize = true;
            this.p1_GameSpeed_Label.ForeColor = System.Drawing.Color.Gray;
            this.p1_GameSpeed_Label.Location = new System.Drawing.Point(648, 281);
            this.p1_GameSpeed_Label.Name = "p1_GameSpeed_Label";
            this.p1_GameSpeed_Label.Size = new System.Drawing.Size(83, 15);
            this.p1_GameSpeed_Label.TabIndex = 20;
            this.p1_GameSpeed_Label.Text = "Game speed: 2";
            // 
            // p1_Console_Label
            // 
            this.p1_Console_Label.AutoSize = true;
            this.p1_Console_Label.ForeColor = System.Drawing.Color.Gray;
            this.p1_Console_Label.Location = new System.Drawing.Point(648, 266);
            this.p1_Console_Label.Name = "p1_Console_Label";
            this.p1_Console_Label.Size = new System.Drawing.Size(72, 15);
            this.p1_Console_Label.TabIndex = 19;
            this.p1_Console_Label.Text = "Console: off";
            // 
            // p1_Sound_Label
            // 
            this.p1_Sound_Label.AutoSize = true;
            this.p1_Sound_Label.ForeColor = System.Drawing.Color.Gray;
            this.p1_Sound_Label.Location = new System.Drawing.Point(648, 251);
            this.p1_Sound_Label.Name = "p1_Sound_Label";
            this.p1_Sound_Label.Size = new System.Drawing.Size(62, 15);
            this.p1_Sound_Label.TabIndex = 18;
            this.p1_Sound_Label.Text = "Sound: on";
            // 
            // p1_Settings_Label
            // 
            this.p1_Settings_Label.AutoSize = true;
            this.p1_Settings_Label.ForeColor = System.Drawing.Color.Gray;
            this.p1_Settings_Label.Location = new System.Drawing.Point(632, 236);
            this.p1_Settings_Label.Name = "p1_Settings_Label";
            this.p1_Settings_Label.Size = new System.Drawing.Size(51, 15);
            this.p1_Settings_Label.TabIndex = 17;
            this.p1_Settings_Label.Text = "Settings";
            // 
            // p1_Random_Label
            // 
            this.p1_Random_Label.AutoSize = true;
            this.p1_Random_Label.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p1_Random_Label.ForeColor = System.Drawing.Color.Gray;
            this.p1_Random_Label.Location = new System.Drawing.Point(648, 211);
            this.p1_Random_Label.Name = "p1_Random_Label";
            this.p1_Random_Label.Size = new System.Drawing.Size(72, 15);
            this.p1_Random_Label.TabIndex = 16;
            this.p1_Random_Label.Text = "Random: off";
            // 
            // p1_Master_Label
            // 
            this.p1_Master_Label.AutoSize = true;
            this.p1_Master_Label.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p1_Master_Label.ForeColor = System.Drawing.Color.Gray;
            this.p1_Master_Label.Location = new System.Drawing.Point(648, 197);
            this.p1_Master_Label.Name = "p1_Master_Label";
            this.p1_Master_Label.Size = new System.Drawing.Size(66, 15);
            this.p1_Master_Label.TabIndex = 15;
            this.p1_Master_Label.Text = "Master: off";
            // 
            // p1_Timer_Label
            // 
            this.p1_Timer_Label.AutoSize = true;
            this.p1_Timer_Label.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.p1_Timer_Label.ForeColor = System.Drawing.Color.Gray;
            this.p1_Timer_Label.Location = new System.Drawing.Point(648, 182);
            this.p1_Timer_Label.Name = "p1_Timer_Label";
            this.p1_Timer_Label.Size = new System.Drawing.Size(58, 15);
            this.p1_Timer_Label.TabIndex = 14;
            this.p1_Timer_Label.Text = "Timer: off";
            // 
            // p1_Addons_Label
            // 
            this.p1_Addons_Label.AutoSize = true;
            this.p1_Addons_Label.ForeColor = System.Drawing.Color.Gray;
            this.p1_Addons_Label.Location = new System.Drawing.Point(632, 167);
            this.p1_Addons_Label.Name = "p1_Addons_Label";
            this.p1_Addons_Label.Size = new System.Drawing.Size(63, 15);
            this.p1_Addons_Label.TabIndex = 13;
            this.p1_Addons_Label.Text = "Addons: 0";
            // 
            // p1_Team_Label
            // 
            this.p1_Team_Label.AutoSize = true;
            this.p1_Team_Label.ForeColor = System.Drawing.Color.Gray;
            this.p1_Team_Label.Location = new System.Drawing.Point(632, 142);
            this.p1_Team_Label.Name = "p1_Team_Label";
            this.p1_Team_Label.Size = new System.Drawing.Size(65, 15);
            this.p1_Team_Label.TabIndex = 12;
            this.p1_Team_Label.Text = "Team: Blue";
            // 
            // p1_Skill_Label
            // 
            this.p1_Skill_Label.AutoSize = true;
            this.p1_Skill_Label.ForeColor = System.Drawing.Color.Gray;
            this.p1_Skill_Label.Location = new System.Drawing.Point(648, 87);
            this.p1_Skill_Label.Name = "p1_Skill_Label";
            this.p1_Skill_Label.Size = new System.Drawing.Size(65, 15);
            this.p1_Skill_Label.TabIndex = 11;
            this.p1_Skill_Label.Text = "Skill: Name";
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.Color.DarkGray;
            this.button3.FlatAppearance.BorderSize = 0;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button3.Font = new System.Drawing.Font("Times New Roman", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button3.ForeColor = System.Drawing.Color.Black;
            this.button3.Location = new System.Drawing.Point(3, 3);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(54, 20);
            this.button3.TabIndex = 10;
            this.button3.Text = "Back";
            this.button3.UseVisualStyleBackColor = false;
            // 
            // playerGold_Label
            // 
            this.playerGold_Label.AutoSize = true;
            this.playerGold_Label.ForeColor = System.Drawing.Color.Gray;
            this.playerGold_Label.Location = new System.Drawing.Point(120, 3);
            this.playerGold_Label.Name = "playerGold_Label";
            this.playerGold_Label.Size = new System.Drawing.Size(44, 15);
            this.playerGold_Label.TabIndex = 9;
            this.playerGold_Label.Text = "Gold: 0";
            // 
            // p1_Difficulty_Label
            // 
            this.p1_Difficulty_Label.AutoSize = true;
            this.p1_Difficulty_Label.ForeColor = System.Drawing.Color.Gray;
            this.p1_Difficulty_Label.Location = new System.Drawing.Point(632, 127);
            this.p1_Difficulty_Label.Name = "p1_Difficulty_Label";
            this.p1_Difficulty_Label.Size = new System.Drawing.Size(101, 15);
            this.p1_Difficulty_Label.TabIndex = 8;
            this.p1_Difficulty_Label.Text = "Difficulty: Normal";
            // 
            // p1_Guard_Label
            // 
            this.p1_Guard_Label.AutoSize = true;
            this.p1_Guard_Label.ForeColor = System.Drawing.Color.Gray;
            this.p1_Guard_Label.Location = new System.Drawing.Point(632, 102);
            this.p1_Guard_Label.Name = "p1_Guard_Label";
            this.p1_Guard_Label.Size = new System.Drawing.Size(75, 15);
            this.p1_Guard_Label.TabIndex = 7;
            this.p1_Guard_Label.Text = "Guard: Name";
            // 
            // p1_General_Label
            // 
            this.p1_General_Label.AutoSize = true;
            this.p1_General_Label.ForeColor = System.Drawing.Color.Gray;
            this.p1_General_Label.Location = new System.Drawing.Point(632, 72);
            this.p1_General_Label.Name = "p1_General_Label";
            this.p1_General_Label.Size = new System.Drawing.Size(83, 15);
            this.p1_General_Label.TabIndex = 6;
            this.p1_General_Label.Text = "General: Name";
            // 
            // p1_Special_Label
            // 
            this.p1_Special_Label.AutoSize = true;
            this.p1_Special_Label.ForeColor = System.Drawing.Color.Gray;
            this.p1_Special_Label.Location = new System.Drawing.Point(648, 57);
            this.p1_Special_Label.Name = "p1_Special_Label";
            this.p1_Special_Label.Size = new System.Drawing.Size(57, 15);
            this.p1_Special_Label.TabIndex = 5;
            this.p1_Special_Label.Text = "Special: 0";
            // 
            // p1_Range_Label
            // 
            this.p1_Range_Label.AutoSize = true;
            this.p1_Range_Label.ForeColor = System.Drawing.Color.Gray;
            this.p1_Range_Label.Location = new System.Drawing.Point(648, 42);
            this.p1_Range_Label.Name = "p1_Range_Label";
            this.p1_Range_Label.Size = new System.Drawing.Size(53, 15);
            this.p1_Range_Label.TabIndex = 4;
            this.p1_Range_Label.Text = "Range: 0";
            // 
            // p1_Melee_Label
            // 
            this.p1_Melee_Label.AutoSize = true;
            this.p1_Melee_Label.ForeColor = System.Drawing.Color.Gray;
            this.p1_Melee_Label.Location = new System.Drawing.Point(648, 27);
            this.p1_Melee_Label.Name = "p1_Melee_Label";
            this.p1_Melee_Label.Size = new System.Drawing.Size(52, 15);
            this.p1_Melee_Label.TabIndex = 3;
            this.p1_Melee_Label.Text = "Melee: 0";
            // 
            // p1_Units_Label
            // 
            this.p1_Units_Label.AutoSize = true;
            this.p1_Units_Label.ForeColor = System.Drawing.Color.Gray;
            this.p1_Units_Label.Location = new System.Drawing.Point(632, 12);
            this.p1_Units_Label.Name = "p1_Units_Label";
            this.p1_Units_Label.Size = new System.Drawing.Size(48, 15);
            this.p1_Units_Label.TabIndex = 2;
            this.p1_Units_Label.Text = "Units: 0";
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.Color.DarkGray;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.ForeColor = System.Drawing.Color.Black;
            this.button2.Location = new System.Drawing.Point(12, 329);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(92, 25);
            this.button2.TabIndex = 1;
            this.button2.Text = "Singleplayer";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.Color.DarkGray;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.ForeColor = System.Drawing.Color.DarkRed;
            this.button1.Location = new System.Drawing.Point(635, 329);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(92, 25);
            this.button1.TabIndex = 0;
            this.button1.Text = "Ready";
            this.button1.UseVisualStyleBackColor = false;
            // 
            // Player1_Blueteam_Button
            // 
            this.Player1_Blueteam_Button.BackColor = System.Drawing.Color.DarkGray;
            this.Player1_Blueteam_Button.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen;
            this.Player1_Blueteam_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Player1_Blueteam_Button.Font = new System.Drawing.Font("Times New Roman", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player1_Blueteam_Button.ForeColor = System.Drawing.Color.Black;
            this.Player1_Blueteam_Button.Location = new System.Drawing.Point(3, 49);
            this.Player1_Blueteam_Button.Name = "Player1_Blueteam_Button";
            this.Player1_Blueteam_Button.Size = new System.Drawing.Size(61, 22);
            this.Player1_Blueteam_Button.TabIndex = 27;
            this.Player1_Blueteam_Button.Text = "Blue";
            this.Player1_Blueteam_Button.UseVisualStyleBackColor = false;
            this.Player1_Blueteam_Button.Click += new System.EventHandler(this.Player1_Blueteam_Button_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Gray;
            this.label2.Location = new System.Drawing.Point(11, 31);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(43, 15);
            this.label2.TabIndex = 28;
            this.label2.Text = "-Team-";
            // 
            // Player1_Redteam_Button
            // 
            this.Player1_Redteam_Button.BackColor = System.Drawing.Color.DarkGray;
            this.Player1_Redteam_Button.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen;
            this.Player1_Redteam_Button.FlatAppearance.BorderSize = 0;
            this.Player1_Redteam_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Player1_Redteam_Button.Font = new System.Drawing.Font("Times New Roman", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player1_Redteam_Button.ForeColor = System.Drawing.Color.Black;
            this.Player1_Redteam_Button.Location = new System.Drawing.Point(3, 74);
            this.Player1_Redteam_Button.Name = "Player1_Redteam_Button";
            this.Player1_Redteam_Button.Size = new System.Drawing.Size(61, 22);
            this.Player1_Redteam_Button.TabIndex = 29;
            this.Player1_Redteam_Button.Text = "Red";
            this.Player1_Redteam_Button.UseVisualStyleBackColor = false;
            this.Player1_Redteam_Button.Click += new System.EventHandler(this.Player1_Redteam_Button_Click);
            // 
            // Player1_Greenteam_Button
            // 
            this.Player1_Greenteam_Button.BackColor = System.Drawing.Color.DarkGray;
            this.Player1_Greenteam_Button.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen;
            this.Player1_Greenteam_Button.FlatAppearance.BorderSize = 0;
            this.Player1_Greenteam_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Player1_Greenteam_Button.Font = new System.Drawing.Font("Times New Roman", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player1_Greenteam_Button.ForeColor = System.Drawing.Color.Black;
            this.Player1_Greenteam_Button.Location = new System.Drawing.Point(3, 99);
            this.Player1_Greenteam_Button.Name = "Player1_Greenteam_Button";
            this.Player1_Greenteam_Button.Size = new System.Drawing.Size(61, 22);
            this.Player1_Greenteam_Button.TabIndex = 30;
            this.Player1_Greenteam_Button.Text = "Green";
            this.Player1_Greenteam_Button.UseVisualStyleBackColor = false;
            this.Player1_Greenteam_Button.Click += new System.EventHandler(this.Player1_Greenteam_Button_Click);
            // 
            // Player1_Yellowteam_Button
            // 
            this.Player1_Yellowteam_Button.BackColor = System.Drawing.Color.DarkGray;
            this.Player1_Yellowteam_Button.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen;
            this.Player1_Yellowteam_Button.FlatAppearance.BorderSize = 0;
            this.Player1_Yellowteam_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Player1_Yellowteam_Button.Font = new System.Drawing.Font("Times New Roman", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Player1_Yellowteam_Button.ForeColor = System.Drawing.Color.Black;
            this.Player1_Yellowteam_Button.Location = new System.Drawing.Point(3, 124);
            this.Player1_Yellowteam_Button.Name = "Player1_Yellowteam_Button";
            this.Player1_Yellowteam_Button.Size = new System.Drawing.Size(61, 22);
            this.Player1_Yellowteam_Button.TabIndex = 31;
            this.Player1_Yellowteam_Button.Text = "Yellow";
            this.Player1_Yellowteam_Button.UseVisualStyleBackColor = false;
            this.Player1_Yellowteam_Button.Click += new System.EventHandler(this.Player1_Yellowteam_Button_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Gray;
            this.label3.Location = new System.Drawing.Point(2, 158);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(65, 15);
            this.label3.TabIndex = 33;
            this.label3.Text = "-Difficulty-";
            // 
            // Easy_Button
            // 
            this.Easy_Button.BackColor = System.Drawing.Color.DarkGray;
            this.Easy_Button.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen;
            this.Easy_Button.FlatAppearance.BorderSize = 0;
            this.Easy_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Easy_Button.Font = new System.Drawing.Font("Times New Roman", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Easy_Button.ForeColor = System.Drawing.Color.Black;
            this.Easy_Button.Location = new System.Drawing.Point(3, 176);
            this.Easy_Button.Name = "Easy_Button";
            this.Easy_Button.Size = new System.Drawing.Size(61, 22);
            this.Easy_Button.TabIndex = 34;
            this.Easy_Button.Text = "Easy";
            this.Easy_Button.UseVisualStyleBackColor = false;
            this.Easy_Button.Click += new System.EventHandler(this.Easy_Button_Click);
            // 
            // Normal_Button
            // 
            this.Normal_Button.BackColor = System.Drawing.Color.DarkGray;
            this.Normal_Button.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen;
            this.Normal_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Normal_Button.Font = new System.Drawing.Font("Times New Roman", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Normal_Button.ForeColor = System.Drawing.Color.Black;
            this.Normal_Button.Location = new System.Drawing.Point(3, 201);
            this.Normal_Button.Name = "Normal_Button";
            this.Normal_Button.Size = new System.Drawing.Size(61, 22);
            this.Normal_Button.TabIndex = 35;
            this.Normal_Button.Text = "Normal";
            this.Normal_Button.UseVisualStyleBackColor = false;
            this.Normal_Button.Click += new System.EventHandler(this.Normal_Button_Click);
            // 
            // Hard_Button
            // 
            this.Hard_Button.BackColor = System.Drawing.Color.DarkGray;
            this.Hard_Button.FlatAppearance.BorderColor = System.Drawing.Color.ForestGreen;
            this.Hard_Button.FlatAppearance.BorderSize = 0;
            this.Hard_Button.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Hard_Button.Font = new System.Drawing.Font("Times New Roman", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Hard_Button.ForeColor = System.Drawing.Color.Black;
            this.Hard_Button.Location = new System.Drawing.Point(3, 226);
            this.Hard_Button.Name = "Hard_Button";
            this.Hard_Button.Size = new System.Drawing.Size(61, 22);
            this.Hard_Button.TabIndex = 36;
            this.Hard_Button.Text = "Hard";
            this.Hard_Button.UseVisualStyleBackColor = false;
            this.Hard_Button.Click += new System.EventHandler(this.Hard_Button_Click);
            // 
            // Boardgame
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(1270, 832);
            this.Controls.Add(this.P1Selection_Panel);
            this.Controls.Add(this.sett_Popup_Label);
            this.Controls.Add(this.Menu3);
            this.Controls.Add(this.OpponentHand_Panel);
            this.Controls.Add(this.PlayerHand_Panel);
            this.Controls.Add(this.OpponentDeck_PictureBox);
            this.Controls.Add(this.PlayerDeck_PictureBox);
            this.Controls.Add(this.Menu2);
            this.Controls.Add(this.Menu1);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Times New Roman", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Boardgame";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "v0.4";
            this.Scroll += new System.Windows.Forms.ScrollEventHandler(this.Boardgame_Scroll);
            this.Menu3.ResumeLayout(false);
            this.OpponentHand_Panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.OpponentHand5_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentHand4_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentHand2_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentHand3_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentHand1_PictureBox)).EndInit();
            this.PlayerHand_Panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHand5_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHand4_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHand2_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHand3_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerHand1_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.OpponentDeck_PictureBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.PlayerDeck_PictureBox)).EndInit();
            this.Menu2.ResumeLayout(false);
            this.Menu1.ResumeLayout(false);
            this.P1Selection_Panel.ResumeLayout(false);
            this.P1Selection_Panel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label sett_Popup_Label;
        private System.Windows.Forms.Panel Menu3;
        private System.Windows.Forms.Button sett_Back_Button;
        private System.Windows.Forms.Button sett_GameSpeed_Button;
        private System.Windows.Forms.Button sett_Console_Button;
        private System.Windows.Forms.Button sett_Sound_Button;
        private System.Windows.Forms.Panel OpponentHand_Panel;
        private System.Windows.Forms.PictureBox OpponentHand5_PictureBox;
        private System.Windows.Forms.PictureBox OpponentHand4_PictureBox;
        private System.Windows.Forms.PictureBox OpponentHand2_PictureBox;
        private System.Windows.Forms.PictureBox OpponentHand3_PictureBox;
        private System.Windows.Forms.PictureBox OpponentHand1_PictureBox;
        private System.Windows.Forms.Panel PlayerHand_Panel;
        private System.Windows.Forms.PictureBox PlayerHand5_PictureBox;
        private System.Windows.Forms.PictureBox PlayerHand4_PictureBox;
        private System.Windows.Forms.PictureBox PlayerHand2_PictureBox;
        private System.Windows.Forms.PictureBox PlayerHand3_PictureBox;
        private System.Windows.Forms.PictureBox PlayerHand1_PictureBox;
        private System.Windows.Forms.PictureBox OpponentDeck_PictureBox;
        private System.Windows.Forms.PictureBox PlayerDeck_PictureBox;
        private System.Windows.Forms.Panel Menu2;
        private System.Windows.Forms.Button add_Back_Button;
        private System.Windows.Forms.Button add_Random_Button;
        private System.Windows.Forms.Button add_Master_Button;
        private System.Windows.Forms.Button add_Timer_Button;
        private System.Windows.Forms.Panel Menu1;
        private System.Windows.Forms.Button Setting_Button;
        private System.Windows.Forms.Button Exit_Button;
        private System.Windows.Forms.Button Addon_Button;
        private System.Windows.Forms.Button Play_Button;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer sett_Popup_Timer;
        private System.Windows.Forms.Panel P1Selection_Panel;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label p1_Difficulty_Label;
        private System.Windows.Forms.Label p1_Guard_Label;
        private System.Windows.Forms.Label p1_General_Label;
        private System.Windows.Forms.Label p1_Special_Label;
        private System.Windows.Forms.Label p1_Range_Label;
        private System.Windows.Forms.Label p1_Melee_Label;
        private System.Windows.Forms.Label p1_Units_Label;
        private System.Windows.Forms.Label playerGold_Label;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label p1_Timer_Label;
        private System.Windows.Forms.Label p1_Addons_Label;
        private System.Windows.Forms.Label p1_Team_Label;
        private System.Windows.Forms.Label p1_Skill_Label;
        private System.Windows.Forms.Label p1_Master_Label;
        private System.Windows.Forms.Label p1_Random_Label;
        private System.Windows.Forms.Label p1_Console_Label;
        private System.Windows.Forms.Label p1_Sound_Label;
        private System.Windows.Forms.Label p1_Settings_Label;
        private System.Windows.Forms.Label p1_GameSpeed_Label;
        private System.Windows.Forms.Button Player1_CardSlot1;
        private System.Windows.Forms.Button Player1_CardSlot2;
        private System.Windows.Forms.Button Player1_CardSlot6;
        private System.Windows.Forms.Button Player1_CardSlot5;
        private System.Windows.Forms.Button Player1_CardSlot4;
        private System.Windows.Forms.Button Player1_CardSlot3;
        private System.Windows.Forms.Button Hard_Button;
        private System.Windows.Forms.Button Normal_Button;
        private System.Windows.Forms.Button Easy_Button;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button Player1_Yellowteam_Button;
        private System.Windows.Forms.Button Player1_Greenteam_Button;
        private System.Windows.Forms.Button Player1_Redteam_Button;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Player1_Blueteam_Button;
    }
}

