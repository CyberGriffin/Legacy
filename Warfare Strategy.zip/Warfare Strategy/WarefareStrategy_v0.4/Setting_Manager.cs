﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WarefareStrategy_v0._4
{
    class Setting_Manager
    {
        #region Variables
        public static bool settings_Sound_Active = true;
        public static bool settings_Console_Active = false;
        public static int settings_GameSpeed_Value = 2;
        #endregion

        public static string difficulty = "Normal";
    }
}
